#include "../Application.h"
#include "PostEffectGuideUI.h"

PostEffectGuideUI::PostEffectGuideUI(void)
{
}

PostEffectGuideUI::~PostEffectGuideUI(void)
{
}

void PostEffectGuideUI::InitEffect(void)
{
    Add((Application::PATH_SHADER + "UIPS.pso").c_str(),
        CONST_BUF_FLOAT4_SIZE, TEX_SLOT_NUM, DX_TEXADDRESS_BORDER);

    int sw, sh;
    GetScreenState(&sw, &sh, nullptr);

    // GuideUI�̕`��̈� (�E��G���A�AGuideUI.cpp�̒萔�ƍ��킹��)
    constexpr int MARGIN_RIGHT = 60;
    constexpr int MARGIN_TOP = 60;
    constexpr int REGION_W = 400; // �v����
    constexpr int REGION_H = 300; // �v����

    float rgnL = (float)(sw - REGION_W - MARGIN_RIGHT) / sw;
    float rgnT = (float)(MARGIN_TOP) / sh;
    float rgnW = (float)(REGION_W) / sw;
    float rgnH = (float)(REGION_H) / sh;

    distortion_ = 0.3f;
    SetConstBuffer(0, 0, { distortion_, 0.0f, 0.0f, 0.0f });
    // ���SUV, �̈�T�C�YUV
    SetConstBuffer(0, 1, { rgnL + rgnW * 0.5f, rgnT + rgnH * 0.5f, rgnW, rgnH });
    // �̈捶��UV
    SetConstBuffer(0, 2, { rgnL, rgnT, 0.0f, 0.0f });
}

void PostEffectGuideUI::Update()
{
	if (CheckHitKey(KEY_INPUT_P)) distortion_ += 0.1;
	if (CheckHitKey(KEY_INPUT_L)) distortion_ -= 0.1;
	SetConstBuffer(0, 0, { distortion_, 0.0f, 0.0f, 0.0f });
}
