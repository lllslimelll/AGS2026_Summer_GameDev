#include "../Common//Transform.h"
#include "ColliderSphere.h"

ColliderSphere::ColliderSphere(
	TAG tag, const Transform* follow,
	const VECTOR& localPos, float radius)
	:
	ColliderBase(SHAPE::SPHERE, tag, follow),
	localPos_(localPos),
	radius_(radius)
{
}

ColliderSphere::~ColliderSphere(void)
{
}

const VECTOR& ColliderSphere::GetLocalPos(void) const
{
	return localPos_;
}

void ColliderSphere::SetLocalPos(const VECTOR& localPos)
{
	localPos_ = localPos;
}

VECTOR ColliderSphere::GetPos(void) const
{
	return GetRotPos(localPos_);
}

float ColliderSphere::GetRadius(void) const
{
	return radius_;
}

void ColliderSphere::SetRadius(float radius)
{
	radius_ = radius;
}

VECTOR ColliderSphere::GetPosPushBackAlongNormal(const MV1_COLL_RESULT_POLY& hitPoly, int maxTryCnt, float pushDistance) const
{
	// �Ǐ]��̎��g�̃C���X�^���X���R�s�[����
	Transform tmpTransform = *follow_;
	ColliderSphere tmpSphere = *this;
	tmpSphere.SetFollow(&tmpTransform);

	// �Փ˕␳����
	int tryCnt = 0;
	while (tryCnt < maxTryCnt)
	{
		// ���̂ƎO�p�`�̓����蔻��
		if (!HitCheck_Sphere_Triangle(
			tmpSphere.GetPos(), tmpSphere.GetRadius(),
			hitPoly.Position[0], hitPoly.Position[1], hitPoly.Position[2]))
		{
			break;
		}

		// �Փ˂��Ă�����@�������ɉ����߂�
		tmpTransform.pos =
			VAdd(tmpTransform.pos, VScale(hitPoly.Normal, pushDistance));

		tryCnt++;
	}

	// �����߂����W��Ԃ�
	return tmpTransform.pos;
}

void ColliderSphere::DrawDebug(int color)
{
	DrawSphere3D(GetPos(), radius_, 16, color, color, false);
}
