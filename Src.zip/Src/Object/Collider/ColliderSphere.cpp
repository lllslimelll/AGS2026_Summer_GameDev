#include "../Common//Transform.h"
#include "ColliderSphere.h"

ColliderSphere::ColliderSphere(
	TAG tag, const Transform* follow,
	const VECTOR& localPos, float radius)
	:
	ColliderBase(SHAPE::SPHERE, tag, follow),
	localPos_(localPos),
	radius_(radius)
{
}

ColliderSphere::~ColliderSphere(void)
{
}

const VECTOR& ColliderSphere::GetLocalPos(void) const
{
	return localPos_;
}

void ColliderSphere::SetLocalPos(const VECTOR& localPos)
{
	localPos_ = localPos;
}

VECTOR ColliderSphere::GetPos(void) const
{
	return GetRotPos(localPos_);
}

float ColliderSphere::GetRadius(void) const
{
	return radius_;
}

void ColliderSphere::SetRadius(float radius)
{
	radius_ = radius;
}

bool ColliderSphere::IsHitRay(const VECTOR& rayStart, const VECTOR& rayEnd) const
{
	const VECTOR center = GetPos();
	const VECTOR dir = VSub(rayEnd, rayStart);
	const VECTOR toCenter = VSub(rayStart, center);

	const float a = VDot(dir, dir);
	const float b = 2.0f * VDot(toCenter, dir);
	const float c = VDot(toCenter, toCenter) - radius_ * radius_;

	// ���ʎ�
	const float discriminant = b * b - 4.0f * a * c;
	if (discriminant < 0.0f) return false;

	// �q�b�g�p�����[�^
	const float sqrtD = sqrtf(discriminant);
	const float len = sqrtf(a);
	const float t0 = (-b - sqrtD) / (2.0f * a);
	const float t1 = (-b + sqrtD) / (2.0f * a);

	return (t0 >= 0.0f && t0 <= len) || (t1 >= 0.0f && t1 <= len);
}

VECTOR ColliderSphere::GetPosPushBackAlongNormal(const MV1_COLL_RESULT_POLY& hitPoly, int maxTryCnt, float pushDistance) const
{
	// �Ǐ]��̎��g�̃C���X�^���X���R�s�[����
	Transform tmpTransform = *follow_;
	ColliderSphere tmpSphere = *this;
	tmpSphere.SetFollow(&tmpTransform);

	// �Փ˕␳����
	int tryCnt = 0;
	while (tryCnt < maxTryCnt)
	{
		// ���̂ƎO�p�`�̓����蔻��
		if (!HitCheck_Sphere_Triangle(
			tmpSphere.GetPos(), tmpSphere.GetRadius(),
			hitPoly.Position[0], hitPoly.Position[1], hitPoly.Position[2]))
		{
			break;
		}

		// �Փ˂��Ă�����@�������ɉ����߂�
		tmpTransform.pos =
			VAdd(tmpTransform.pos, VScale(hitPoly.Normal, pushDistance));

		tryCnt++;
	}

	// �����߂����W��Ԃ�
	return tmpTransform.pos;
}

void ColliderSphere::DrawDebug(int color)
{
	DrawSphere3D(GetPos(), radius_, 16, color, color, false);
}
