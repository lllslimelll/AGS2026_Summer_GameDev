// GuideUI.cpp
#include <DxLib.h>
#include "../../Actor/Charactor/Player.h"
#include "../../../Manager/ScreenManager.h"
#include "../../../PostEffect/PostEffectGuideUI.h"
#include "GuideUI.h"

GuideUI::GuideUI(const Player& player)
    : 
    GameUI(),
    player_(player)
{
    // �K�C�hUI�p�|�X�g�G�t�F�N�g
    int screen = ScreenManager::GetInstance().GetGuideUIScreen(); // ���C���X�N���[���擾
    pEffectGuideUI_ = std::make_unique<PostEffectGuideUI>(); // ����
    // �������ƑΏۃX�N���[���̐ݒ�
    pEffectGuideUI_->Init(screen);
    pEffectGuideUI_->SetEnabled(true);
}

void GuideUI::Update(void)
{
    pEffectGuideUI_->Update();
}

void GuideUI::Draw(void)
{
    int guideScreen = ScreenManager::GetInstance().GetGuideUIScreen();
    int mainScreen = ScreenManager::GetInstance().GetMainScreen();

    // �@ guideScreen�Ƀe�L�X�g�`��
    SetDrawScreen(guideScreen);
    ClearDrawScreen();

    const auto info = player_.GetGuideInfo();

    int screenW, screenH;
    GetScreenState(&screenW, &screenH, nullptr);

    int prevSize = GetFontSize();

    constexpr int MARGIN_RIGHT = 60;
    constexpr int MARGIN_TOP = 60;
    constexpr int GOAL_FONT = 42;

    constexpr int SCORE_FONT = 50;
    constexpr int NORMA_FONT = 32;
    constexpr int LINE_FONT = 36;
    constexpr int LINE_SPAN = 50;

    int y = MARGIN_TOP;

    // ===== �ړI�\�� =====
    SetFontSize(GOAL_FONT);

    const char* goal = info.hasAnyItem ? "���P�b�g�ɔ[�i����" : "�A�C�e�������W����";
    int goalW = GetDrawStringWidth(goal, (int)strlen(goal));
    DrawString(screenW - goalW - MARGIN_RIGHT, y, goal, 0x00ff80);
    y += GOAL_FONT + 10;

    // ===== ���݂̔[�i�z =====
    SetFontSize(SCORE_FONT);

    auto withComma = [](int value, char* out)
        {
            char tmp[32];
            sprintf_s(tmp, 32, "%d", value);
            int len = (int)strlen(tmp);
            int o = 0;
            int firstLen = len % 3;
            if (firstLen == 0) firstLen = 3;
            for (int i = 0; i < firstLen; i++) out[o++] = tmp[i];
            for (int i = firstLen; i < len; i += 3)
            {
                out[o++] = ',';
                out[o++] = tmp[i];
                out[o++] = tmp[i + 1];
                out[o++] = tmp[i + 2];
            }
            out[o] = '\0';
        };

    char scoreStr[32];
    withComma(info.totalDelivered, scoreStr);
    char scoreBuf[48];
    sprintf_s(scoreBuf, "$%s", scoreStr);

    int scoreW = GetDrawStringWidth(scoreBuf, (int)strlen(scoreBuf));
    DrawString(screenW - scoreW - MARGIN_RIGHT, y, scoreBuf, 0xffffff);
    y += SCORE_FONT + 4;
    
    // ===== �m���}���z =====
    SetFontSize(NORMA_FONT);

    char quotaStr[32];
    withComma(info.quota, quotaStr);
    char quotaBuf[48];
    sprintf_s(quotaBuf, "/ $%s", quotaStr);

    int quotaW = GetDrawStringWidth(quotaBuf, (int)strlen(quotaBuf));
    DrawString(screenW - quotaW - MARGIN_RIGHT, y, quotaBuf, 0x888888);
    y += NORMA_FONT + 16;

    // ===== ���� =====
    const int lineR = screenW - MARGIN_RIGHT;
    const int lineL = lineR - max(max(goalW, scoreW), quotaW) - 20;
    DrawLine(lineL, y, lineR, y, 0x888888);
    y += 20;

    // ===== ����K�C�h =====
    const char* labels[MAX_LABELS];
    int count = 0;

    if (info.canPickUp)
    {
        labels[count++] = info.isPad ? "�E�� : [X]" : "�E�� : [F]";
    }

    if (info.isAimingRocket)
    {
        if (info.hasSelectedItem)
        {
            labels[count++] = info.isPad ? "�[�i : [X]" : "�[�i : [F]";
        }
        labels[count++] = info.isPad ? "�A�� : [B]" : "�A�� : [E]";
    }

    if (info.hasSelectedItem && info.isIdle)
    {
        labels[count++] = info.isPad ? "�u�� : [Y]" : "�u�� : [G]";
    }

    SetFontSize(LINE_FONT);

    for (int i = 0; i < count; i++)
    {
        const char* buf = labels[i];
        int textW = GetDrawStringWidth(buf, (int)strlen(buf));
        DrawString(screenW - textW - MARGIN_RIGHT, y + i * LINE_SPAN, buf, 0xdddddd);
    }

    SetFontSize(prevSize);

    // �|�X�g�G�t�F�N�g
    pEffectGuideUI_->Draw();

    // �B mainScreen�ɘc�ݍς݂�����
    SetDrawScreen(mainScreen);
    DrawGraph(0, 0, guideScreen, true);
}