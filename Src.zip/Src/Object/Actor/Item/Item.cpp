#include <DxLib.h>
#include "../../../Utility/AsoUtility.h"
#include "../../../Scene/SceneManager.h"
#include "../../../Manager/Camera.h"
#include "../../../Manager/ResourceManager.h"
#include "../../../Manager/SoundManager.h"
#include "../../Collider/ColliderBase.h"
#include "../../Collider/ColliderModel.h"
#include "Item.h"

Item::Item(const ItemData& data)
    :
    ActorBase(),
    type_(data.type),
    grade_(data.grade),
    defaultPos_(data.defaultPos),
    value_(data.value),
    valueBillImg_{ -1, -1, -1 },
    isAimed_(false),
    isSelected_(false)
{
}

Item::~Item()
{
}

void Item::Update(void)
{
	// �ړ��O���W���X�V
	//prevPos_ = transform_.pos;

	// �X�V����
	//UpdateProcess();

	// ��ԕʍX�V
	stateUpdate_();

	// �d�͂ɂ��ړ���
	//CalcGravityPow();

	// �Փ˔���
	//Collision();

	// ���f������X�V
	transform_.Update();

	// �X�V�㏈��
	//UpdateProcessPost();
}

void Item::Draw(void)
{
   // ���f���`��
   //if (transform_.modelId != -1) return;

   //MV1DrawModel(transform_.modelId);


	// �����Ă��� or �C���x���g�����őI������Ă��Ԃ̂Ƃ��A�A�C�e����`��
    bool shouldDraw = (state_ == STATE::DROPPED) || isSelected_;

    if (shouldDraw)
    {
        int color;
        switch (type_)
        {
        case TYPE::type1: color = 0xffff00; break;
        case TYPE::type2: color = 0x00ffff; break;
        case TYPE::type3: color = 0xff00ff; break;
        default:
            break;
        }

        // �����Ă�Ƃ�30�A�����Ă�Ƃ�10
        float radius = (state_ == STATE::DROPPED) ? 30.0f : 10.0f;

        DrawSphere3D(transform_.pos, radius, 8, color, color, TRUE);

    }
    // ��ԕʕ`��
    stateDraw_();

#ifdef _DEBUG

    // ���L���Ă���R���C�_�̕`��
    for (const auto& own : ownColliders_)
    {
        //own.second->Draw();
    }
#endif
}

void Item::OnPickedUp(void)
{
    SoundManager::GetInstance().PlayPickUp();
	// �A�C�e���������Ă����ԂɑJ��
    ChangeState(STATE::HELD);
}

void Item::OnThrow(const VECTOR& throwDir)
{
    ChangeState(STATE::THROW);
}

void Item::OnDelivered(void)
{
    ChangeState(STATE::DELIVERED);
}

void Item::OnHitEnemy(void)
{
}

Item::TYPE Item::GetType(void) const
{
    return type_;
}

int Item::GetValue(void) const
{
    return value_;
}

Item::GRADE Item::GetGrade(void) const
{
    return grade_;
}

Item::STATE Item::GetState(void) const
{
    return state_;
}

bool Item::IsAimed(const VECTOR& rayOrigin, const VECTOR& rayEnd) const
{
    if (state_ != STATE::DROPPED) return false;

    // �X�t�B�A����
    bool hit = AsoUtility::IsHitSphereCapsule(
        transform_.pos, 30.0f,
        rayOrigin, rayEnd, 0.0f);

    if (!hit) return false;

    // �Օ��`�F�b�N
    for (const auto& c : hitColliders_)
    {
        if (c->GetShape() != ColliderBase::SHAPE::MODEL)
            continue;

        const ColliderModel* model =
            static_cast<const ColliderModel*>(c);

        auto result = model->GetNearestHitPolyLine(
            rayOrigin, transform_.pos);

        if (result.HitFlag > 0) return false;
    }

    return true;
}

void Item::SetAimed(bool aimed)
{
    isAimed_ = aimed;
}

void Item::SetSelected(bool selected)
{
	isSelected_ = selected;
}

void Item::SetHeldPos(const VECTOR& pos)
{
    if (state_ != STATE::HELD) return;
    transform_.pos = pos;
}

void Item::SetNouhin(bool nouhin)
{
    isNouhinn_ = nouhin;
}

void Item::InitLoad(void)
{
    //// ���f���ǂݍ���
    //transform_.SetModel(resMng_.Dupulicate(			// 1�� = Load()  ���� = Depulicate()
    //    ResourceManager::SRC::MAIN_STAGE).handleId_);

	// �A�C�e�����l�̃r���{�[�h�摜�ǂݍ���
    valueBillImg_[0] = LoadGraph("Data/Image/$100.png");
	valueBillImg_[1] = LoadGraph("Data/Image/$500.png");
	valueBillImg_[2] = LoadGraph("Data/Image/$1,000.png");

    if (valueBillImg_[0] == -1)
    {
        printfDx("$100.png �̃��[�h���s\n");
    }
}

void Item::InitTransform(void)
{
    // ���f���̊�{�ݒ�

    // �傫��
    transform_.scl = AsoUtility::VECTOR_ONE;

    // ���f���{���̌���
    transform_.quaRot = Quaternion::Identity();
    // ���[�J����]
    transform_.quaRotLocal = Quaternion::Euler({ 0.0f, DX_PI_F / 180.0f, 0.0f });

    // ���W
    transform_.pos = defaultPos_;

    VECTOR upVec = VNorm((VSub(transform_.pos, { 0,0,0 })));
    transform_.pos = VAdd(transform_.pos, VScale(upVec, 34));

    transform_.Update();
}

void Item::InitCollider(void)
{
}

void Item::InitAnimation(void)
{
}

void Item::InitPost(void)
{
	// ��ԑJ�ڂ̏����o�^
    stateChanges_[STATE::DROPPED] = 
        std::bind(&Item::ChangeDropped, this);
    stateChanges_[STATE::HELD] =
        std::bind(&Item::ChangeHeld, this);
	stateChanges_[STATE::THROW] =
        std::bind(&Item::ChangeThrow, this);
    stateChanges_[STATE::DELIVERED] =
        std::bind(&Item::ChangeDelivered, this);

    // �������
    ChangeState(STATE::DROPPED);

}

void Item::ChangeState(STATE state)
{
    state_ = state;
    
	// �e��ԑJ�ڂ̏���
    stateChanges_[state_]();
}

void Item::ChangeDropped(void)
{
    stateUpdate_ = std::bind(&Item::UpdateDropped, this);
    stateDraw_ = std::bind(&Item::DrawDropped, this);
}

void Item::ChangeHeld(void)
{
    stateUpdate_ = std::bind(&Item::UpdateHeld, this);
    stateDraw_ = std::bind(&Item::DrawHeld, this);
}

void Item::ChangeThrow(void)
{
    stateUpdate_ = std::bind(&Item::UpdateThrow, this);
    stateDraw_ = std::bind(&Item::DrawThrow, this);
}

void Item::ChangeDelivered(void)
{
    stateUpdate_ = std::bind(&Item::UpdateDelivered, this);
    stateDraw_ = std::bind(&Item::DrawDelelivered, this);
}

void Item::UpdateDropped(void)
{
}

void Item::UpdateHeld(void)
{
}

void Item::UpdateThrow(void)
{
}

void Item::UpdateDelivered(void)
{

}

void Item::DrawDropped(void)
{
	// �W���ɓ������Ă��鎞�������l�̃r���{�[�h�摜�`��
    if (isAimed_)
    {
        // �r���{�[�h�摜�̑���Ƀf�o�b�O�����ŉ��l��\��
        // 3D���W���X�N���[�����W�ɕϊ�
        VECTOR screenPos = ConvWorldPosToScreenPos(transform_.pos);

        // �J�����̌��ɂ���ꍇ�͕`�悵�Ȃ��iz > 1.0f�j
        if (screenPos.z <= 1.0f)
        {
            int prevSize = GetFontSize();
            SetFontSize(32);
            DrawFormatString(
                (int)screenPos.x,
                (int)screenPos.y,
                GetColor(255, 255, 255),
                "$%d", value_);
            SetFontSize(prevSize);
        }
    }
}

void Item::DrawHeld(void)
{
    
}

void Item::DrawThrow(void)
{
  
}

void Item::DrawDelelivered(void)
{
}

void Item::UpdateThrowMove(void)
{
}

void Item::DrawBillboard(void) const
{
    VECTOR Vec = VNorm(VSub(scnMng_.GetCamera()->GetTransform().pos, transform_.pos));
    

    switch (type_)
    {
    case TYPE::type1:
        DrawBillboard3D(VAdd(transform_.pos, VScale(Vec, 32.0f)), 0.5f, 0.5f, 50.0f, 0.0f, valueBillImg_[0], true);
        break;
	case TYPE::type2:
        DrawBillboard3D(VAdd(transform_.pos, VScale(Vec, 32.0f)), 0.5f, 0.5f, 50.0f, 0.0f, valueBillImg_[1], true);
		break;
	case TYPE::type3:
		DrawBillboard3D(VAdd(transform_.pos, VScale(Vec, 32.0f)), 0.5f, 0.5f, 50.0f, 0.0f, valueBillImg_[2], true);
		break;
    }
}
