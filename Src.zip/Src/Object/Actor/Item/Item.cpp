#include <DxLib.h>
#include "../../../Utility/AsoUtility.h"
#include "../../../Manager/SceneManager.h"
#include "../../../Manager/Camera.h"
#include "../../../Manager/ResourceManager.h"
#include "../../Collider/ColliderBase.h"
#include "../../Collider/ColliderModel.h"
#include "Item.h"

Item::Item(const ItemData& data)
    :
    ActorBase(),
    type(data.type),
    grade_(data.grade),
    defaultPos_(data.defaultPos),
    value_(data.value),
    isAimed_(false)
{
}

Item::~Item()
{
}

void Item::Update(void)
{
	// �ړ��O���W���X�V
	//prevPos_ = transform_.pos;

	// �X�V����
	//UpdateProcess();

	// ��ԕʍX�V
	stateUpdate_();

	// �d�͂ɂ��ړ���
	//CalcGravityPow();

	// �Փ˔���
	//Collision();

	// ���f������X�V
	transform_.Update();

	// �X�V�㏈��
	//UpdateProcessPost();
}

void Item::Draw(void)
{
   // if(state_ == STATE::HELD || )
	
	ActorBase::Draw();

#ifdef _DEBUG
   int color;

    if (isAimed_)
    {
        // �Ə����͐Ԃœ���
        color = 0xff0000;
    }
    else
    {
        // ��ʂ��ƂɐF��ς���
        switch (type)
        {
        case TYPE::COIN: color = 0xffff00; break; // ���F
        case TYPE::GEM:  color = 0x00ffff; break; // ���F
        default:         color = 0xff0000; break; // �ԁi����`�j
        }
    }

    DrawSphere3D(transform_.pos, 30.0f, 8, color, color, TRUE);
#endif
}

void Item::OnPickedUp(void)
{
	// �A�C�e���������Ă����ԂɑJ��
    ChangeState(STATE::HELD);
}

void Item::OnThrow(const VECTOR& throwDir)
{
    ChangeState(STATE::THROW);
}

void Item::OnHitEnemy(void)
{
}

int Item::GetValue(void) const
{
    return 0;
}

Item::GRADE Item::GetGrade(void) const
{
    return grade_;
}

Item::STATE Item::GetState(void) const
{
    return state_;
}

bool Item::IsAimedBy(const VECTOR& rayOrigin, const VECTOR& rayEnd) const
{
    if (state_ != STATE::DROPPED) return false;

    // �X�t�B�A����
    bool hit = AsoUtility::IsHitSphereCapsule(
        transform_.pos, 30.0f,
        rayOrigin, rayEnd, 0.0f);

    if (!hit) return false;

    // �Օ��`�F�b�N
    for (const auto& c : hitColliders_)
    {
        if (c->GetShape() != ColliderBase::SHAPE::MODEL)
            continue;

        const ColliderModel* model =
            static_cast<const ColliderModel*>(c);

        auto result = model->GetNearestHitPolyLine(
            rayOrigin, transform_.pos);

        if (result.HitFlag > 0) return false;
    }

    return true;
}

void Item::SetAimed(bool aimed)
{
    isAimed_ = aimed;
}

void Item::InitLoad(void)
{
    //// ���f���ǂݍ���
    //transform_.SetModel(resMng_.Dupulicate(			// 1�� = Load()  ���� = Depulicate()
    //    ResourceManager::SRC::MAIN_STAGE).handleId_);
}

void Item::InitTransform(void)
{
    // ���f���̊�{�ݒ�

    // �傫��
    transform_.scl = AsoUtility::VECTOR_ONE;

    // ���f���{���̌���
    transform_.quaRot = Quaternion::Identity();
    // ���[�J����]
    transform_.quaRotLocal = Quaternion::Euler({ 0.0f, DX_PI_F / 180.0f, 0.0f });

    // ���W
    transform_.pos = defaultPos_;

    transform_.Update();
}

void Item::InitCollider(void)
{
}

void Item::InitAnimation(void)
{
}

void Item::InitPost(void)
{
	// ��ԑJ�ڂ̏����o�^
    stateChanges_[STATE::DROPPED] = 
        std::bind(&Item::ChangeDropped, this);
    stateChanges_[STATE::HELD] =
        std::bind(&Item::ChangeHeld, this);
	stateChanges_[STATE::THROW] =
        std::bind(&Item::ChangeThrow, this);

    // �������
    ChangeState(STATE::DROPPED);

}

void Item::ChangeState(STATE state)
{
    state_ = state;
    
	// �e��ԑJ�ڂ̏���
    stateChanges_[state_]();
}

void Item::ChangeDropped(void)
{
    stateUpdate_ = std::bind(&Item::UpdateDropped, this);
}

void Item::ChangeHeld(void)
{
    stateUpdate_ = std::bind(&Item::UpdateHeld, this);
}

void Item::ChangeThrow(void)
{
    stateUpdate_ = std::bind(&Item::UpdateThrow, this);
}

void Item::UpdateDropped(void)
{
}

void Item::UpdateHeld(void)
{
	// �A�C�e���������Ă���v���C���[�̍��W�ɒǏ]������
	transform_.pos = VAdd(scnMng_.GetCamera()->GetTransform().pos, VGet(0.0f, 200.0f, 0.0f));
}

void Item::UpdateThrow(void)
{
}

void Item::UpdateThrowMove(void)
{
}

void Item::DrawBillboard(void) const
{
}
