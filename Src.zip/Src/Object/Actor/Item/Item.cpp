#include <DxLib.h>
#include "../../../Utility/AsoUtility.h"
#include "../../../Manager/SceneManager.h"
#include "../../../Manager/ResourceManager.h"
#include "../../Collider/ColliderBase.h"
#include "../../Collider/ColliderModel.h"
#include "Item.h"

Item::Item(const ItemData& data)
    :
    ActorBase(),
    type(data.type),
    grade_(data.grade),
    defaultPos_(data.defaultPos),
    value_(data.value),
    isAimed_(false)
{
}

Item::~Item()
{
}

void Item::Update(void)
{
	// �ړ��O���W���X�V
	//prevPos_ = transform_.pos;

	// �X�V����
	//UpdateProcess();

	// �d�͂ɂ��ړ���
	//CalcGravityPow();

	// �Փ˔���
	//Collision();

	// ���f������X�V
	transform_.Update();

	// �X�V�㏈��
	//UpdateProcessPost();
}

void Item::Draw(void)
{
	// ���N���X�`�揈��
	ActorBase::Draw();

#ifdef _DEBUG
    // �Ə����������Ă���Ƃ��X�t�B�A��΁A�ʏ�͐Ԃŕ\��
    int color = isAimed_ ? 0x00ff00 : 0xff0000;
    DrawSphere3D(transform_.pos, 30.0f, 8, color, color, FALSE);
#endif
}

void Item::OnPickedUp(void)
{
}

void Item::OnThrow(const VECTOR& throwDir)
{
}

void Item::OnHitEnemy(void)
{
}

int Item::GetValue(void) const
{
    return 0;
}

Item::GRADE Item::GetGrade(void) const
{
    return grade_;
}

Item::STATE Item::GetState(void) const
{
    return state_;
}

bool Item::IsAimedBy(const VECTOR& rayOrigin, const VECTOR& rayEnd) const
{
    if (state_ != STATE::DROPPED) return false;

    // �X�t�B�A����
    bool hit = AsoUtility::IsHitSphereCapsule(
        transform_.pos, 30.0f,
        rayOrigin, rayEnd, 0.0f);

    if (!hit) return false;

    // �Օ��`�F�b�N
    for (const auto& c : hitColliders_)
    {
        if (c->GetShape() != ColliderBase::SHAPE::MODEL)
            continue;

        const ColliderModel* model =
            static_cast<const ColliderModel*>(c);

        auto result = model->GetNearestHitPolyLine(
            rayOrigin, transform_.pos);

        if (result.HitFlag > 0) return false;
    }

    return true;
}

void Item::SetAimed(bool aimed)
{
    isAimed_ = aimed;
}

void Item::InitLoad(void)
{
    //// ���f���ǂݍ���
    //transform_.SetModel(resMng_.Dupulicate(			// 1�� = Load()  ���� = Depulicate()
    //    ResourceManager::SRC::MAIN_STAGE).handleId_);
}

void Item::InitTransform(void)
{
    // ���f���̊�{�ݒ�

    // �傫��
    transform_.scl = AsoUtility::VECTOR_ONE;

    // ���f���{���̌���
    transform_.quaRot = Quaternion::Identity();
    // ���[�J����]
    transform_.quaRotLocal = Quaternion::Euler({ 0.0f, DX_PI_F / 180.0f, 0.0f });

    // ���W
    transform_.pos = defaultPos_;

    transform_.Update();
}

void Item::InitCollider(void)
{
}

void Item::InitAnimation(void)
{
}

void Item::InitPost(void)
{
	// ������Ԃ͗����Ă�����
	state_ = STATE::DROPPED;
}

void Item::ChangeState(STATE state)
{
    state_ = state;
    
	// �e��ԑJ�ڏ���
    stateChanges_[state_]();

    //switch (state_)
    //{
    //case STATE::DROPPED: ChangeDropped(); break;
    //case STATE::HELD:    ChangeHeld();    break;
    //case STATE::Throw:  ChangeThrow();  break;
    //default: break;
    //}
}

void Item::ChangeDropped(void)
{
    stateUpdate_ = std::bind(&Item::UpdateDropped, this);
}

void Item::ChangeHeld(void)
{
    stateUpdate_ = std::bind(&Item::UpdateHeld, this);
}

void Item::ChangeThrow(void)
{
    stateUpdate_ = std::bind(&Item::UpdateThrow, this);
}

void Item::UpdateDropped(void)
{
}

void Item::UpdateHeld(void)
{
}

void Item::UpdateThrow(void)
{
}

void Item::UpdateThrowMove(void)
{
}

void Item::DrawBillboard(void) const
{
}
