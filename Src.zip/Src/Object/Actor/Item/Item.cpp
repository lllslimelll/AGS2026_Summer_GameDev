#include <DxLib.h>
#include "../../../Utility/AsoUtility.h"
#include "../../../Scene/SceneManager.h"
#include "../../../Camera/Camera.h"
#include "../../../Manager/ResourceManager.h"
#include "../../../Manager/SoundManager.h"
#include "../../Collider/ColliderBase.h"
#include "../../Collider/ColliderSphere.h"
#include "Item.h"

void Item::SetCameraPos(const VECTOR& pos)
{
	camPos_ = pos;
}

Item::Item(const ItemData& data)
    :
    ActorBase(),
    type_(data.type),
    grade_(data.grade),
    defaultPos_(data.defaultPos),
    value_(data.value),
    valueBillImg_{ -1, -1, -1 },
    isAimed_(false),
    isSelected_(false)
{
}

Item::~Item()
{
}

void Item::Update(void)
{
	// �ړ��O���W���X�V
	//prevPos_ = transform_.pos;

	// �X�V����
	//UpdateProcess();

	// ��ԕʍX�V
	stateUpdate_();

	// �d�͂ɂ��ړ���
	//CalcGravityPow();

	// �Փ˔���
	//Collision();

	// ���f������X�V
	transform_.Update();

    UpdateCurvatureShader();

	// �X�V�㏈��
	//UpdateProcessPost();
}

void Item::Draw(void)
{
    // ���f���`��
   //if (transform_.modelId != -1) return;

   //MV1DrawModel(transform_.modelId);


	// �����Ă���
    bool shouldDraw = (state_ == STATE::DROPPED);

    if (shouldDraw)
    {
        ActorBase::Draw();
    }

    // ��ԕʕ`��
    stateDraw_();

#ifdef _DEBUG

    // ���L���Ă���R���C�_�̕`��
    for (const auto& own : ownColliders_)
    {
        //own.second->Draw();
    }
#endif
}

void Item::OnPickedUp(void)
{
    SoundManager::GetInstance().PlayPickUp();
	// �A�C�e���������Ă����ԂɑJ��
    ChangeState(STATE::HELD);
}

void Item::OnThrow(const VECTOR& throwDir)
{
    ChangeState(STATE::THROW);
}

void Item::OnDelivered(void)
{
    ChangeState(STATE::DELIVERED);
}

void Item::OnHitEnemy(void)
{
}

Item::TYPE Item::GetType(void) const
{
    return type_;
}

int Item::GetValue(void) const
{
    return value_;
}

Item::GRADE Item::GetGrade(void) const
{
    return grade_;
}

Item::STATE Item::GetState(void) const
{
    return state_;
}

bool Item::IsAimed(const VECTOR& rayOrigin, const VECTOR& rayEnd) const
{
    if (state_ != STATE::DROPPED) return false;

    //if (ownColliders_.count(static_cast<int>(COLLIDER_TYPE::SPHERE)) == 0) return false;

    //const ColliderSphere* col = dynamic_cast<const ColliderSphere*>(
    //    ownColliders_.at(static_cast<int>(COLLIDER_TYPE::SPHERE)));

    //if (col == nullptr || !col->IsHitRay(rayOrigin, rayEnd)) return false;

    // �Օ��`�F�b�N
    //if (IsOccludedByColliders(rayOrigin, transform_.pos)) return false;

        // ��UAsoUtility�Ŋm�F
    bool hit = AsoUtility::IsHitSphereCapsule(
        transform_.pos, 30.0f,
        rayOrigin, rayEnd, 0.0f);

    return hit;
}

void Item::SetAimed(bool aimed)
{
    isAimed_ = aimed;
}

void Item::SetSelected(bool selected)
{
	isSelected_ = selected;
}

void Item::SetHeldPos(const VECTOR& pos)
{
    if (state_ != STATE::HELD) return;
    transform_.pos = pos;
    transform_.Update();
}

void Item::SetNouhin(bool nouhin)
{
    isNouhinn_ = nouhin;
}

void Item::OnDrop(const VECTOR& pos)
{
    // �v���C���[�̑������W���Z�b�g
    transform_.pos = pos;  

    VECTOR up = VNorm(VSub(pos, { 0.0f, 0.0f, 0.0f }));
    VECTOR forward = AsoUtility::DIR_F;
    float dot = VDot(forward, up);
    if (fabsf(dot) > 0.99f) { forward = AsoUtility::DIR_R; }
    forward = VNorm(VSub(forward, VScale(up, dot)));
    transform_.quaRot = Quaternion::LookRotation(forward, up);

    transform_.Update();
    ChangeState(STATE::DROPPED);
}

void Item::InitLoad(void)
{
    //// ���f���ǂݍ���
    //transform_.SetModel(resMng_.Dupulicate(			// 1�� = Load()  ���� = Depulicate()
    //    ResourceManager::SRC::MAIN_STAGE).handleId_);

    switch (type_)
    {
    case TYPE::type1:
        transform_.SetModel(MV1LoadModel("Data/Model/Item/crystal1.mv1"));
        break;
    case TYPE::type2:
        transform_.SetModel(MV1LoadModel("Data/Model/Item/crystal2.mv1"));
        break;
    //case TYPE::type3:
    //    transform_.SetModel(MV1LoadModel("Data/Model/Item/crystal3.mv1"));
    //    break;
    }
}

void Item::InitTransform(void)
{
    // ���f���̊�{�ݒ�

    // �傫��
    transform_.scl = { 50.0f,50.0f ,50.0f };

    // ���f���{���̌���
    transform_.quaRot = Quaternion::Euler({ 0.0f, 0.0f, 0.0f });

    // ���W
    transform_.pos = defaultPos_;

    VECTOR upVec = AsoUtility::DIR_U;
    transform_.pos = VAdd(transform_.pos, VScale(upVec, 60));

    transform_.Update();
}

void Item::InitCollider(void)
{
    // �J�v�Z���R���C�_
    ColliderBase* colSphere = new ColliderSphere(
        ColliderBase::TAG::ITEM, &transform_,
        AsoUtility::VECTOR_ZERO, 50.0f);

    ownColliders_.emplace(static_cast<int>(COLLIDER_TYPE::SPHERE), colSphere);
}

void Item::InitAnimation(void)
{
}

void Item::InitPost(void)
{
	// ��ԑJ�ڂ̏����o�^
    stateChanges_[STATE::DROPPED] = 
        std::bind(&Item::ChangeDropped, this);
    stateChanges_[STATE::HELD] =
        std::bind(&Item::ChangeHeld, this);
	stateChanges_[STATE::THROW] =
        std::bind(&Item::ChangeThrow, this);
    stateChanges_[STATE::DELIVERED] =
        std::bind(&Item::ChangeDelivered, this);

    // �������
    ChangeState(STATE::DROPPED);

    InitCurvatureShader();

}

void Item::ChangeState(STATE state)
{
    state_ = state;
    
	// �e��ԑJ�ڂ̏���
    stateChanges_[state_]();
}

void Item::ChangeDropped(void)
{
    stateUpdate_ = std::bind(&Item::UpdateDropped, this);
    stateDraw_ = std::bind(&Item::DrawDropped, this);
}

void Item::ChangeHeld(void)
{
    stateUpdate_ = std::bind(&Item::UpdateHeld, this);
    stateDraw_ = std::bind(&Item::DrawHeld, this);
}

void Item::ChangeThrow(void)
{
    stateUpdate_ = std::bind(&Item::UpdateThrow, this);
    stateDraw_ = std::bind(&Item::DrawThrow, this);
}

void Item::ChangeDelivered(void)
{
    stateUpdate_ = std::bind(&Item::UpdateDelivered, this);
    stateDraw_ = std::bind(&Item::DrawDelelivered, this);
}

void Item::UpdateDropped(void)
{
}

void Item::UpdateHeld(void)
{
}

void Item::UpdateThrow(void)
{
}

void Item::UpdateDelivered(void)
{

}

void Item::DrawDropped(void)
{
	// �W���ɓ������Ă��鎞�������l�̃r���{�[�h�摜�`��
    if (isAimed_)
    {
        // �r���{�[�h�摜�̑���Ƀf�o�b�O�����ŉ��l��\��
        // 3D���W���X�N���[�����W�ɕϊ�
        VECTOR screenPos = ConvWorldPosToScreenPos(transform_.pos);

        // �J�����̌��ɂ���ꍇ�͕`�悵�Ȃ��iz > 1.0f�j
        if (screenPos.z <= 1.0f)
        {
            int prevSize = GetFontSize();
            SetFontSize(32);
            DrawFormatString(
                (int)screenPos.x,
                (int)screenPos.y,
                GetColor(255, 255, 255),
                "$%d", value_);
            SetFontSize(prevSize);
        }
    }
}

void Item::DrawHeld(void)
{
    
}

void Item::DrawThrow(void)
{
  
}

void Item::DrawDelelivered(void)
{
}

void Item::UpdateThrowMove(void)
{
}

void Item::DrawBillboard(void) const
{
    VECTOR Vec = VNorm(VSub(camPos_, transform_.pos));

    switch (type_)
    {
    case TYPE::type1:
        DrawBillboard3D(VAdd(transform_.pos, VScale(Vec, 32.0f)), 0.5f, 0.5f, 50.0f, 0.0f, valueBillImg_[0], true);
        break;
	case TYPE::type2:
        DrawBillboard3D(VAdd(transform_.pos, VScale(Vec, 32.0f)), 0.5f, 0.5f, 50.0f, 0.0f, valueBillImg_[1], true);
		break;
	case TYPE::type3:
		DrawBillboard3D(VAdd(transform_.pos, VScale(Vec, 32.0f)), 0.5f, 0.5f, 50.0f, 0.0f, valueBillImg_[2], true);
		break;
    }
}
