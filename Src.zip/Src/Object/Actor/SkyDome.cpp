#include "../../Manager/ResourceManager.h"
#include "../../Scene/SceneManager.h"
#include "../Common/Transform.h"
#include "../../Utility/AsoUtility.h"
#include "SkyDome.h"
#include "../../Camera/Camera.h"

SkyDome::SkyDome(const Transform& followTransform)
	:
	followTransform_(followTransform),
	state_(STATE::FOLLOW),
	ActorBase()
{
}

SkyDome::~SkyDome()
{
}

void SkyDome::Update(void)
{
	switch (state_)
	{
	case SkyDome::STATE::NONE:
		UpdateNone();
		break;
	case SkyDome::STATE::STAY:
		UpdateStay();
		break;
	case SkyDome::STATE::FOLLOW:
		UpdateFollow();
		break;
	}


	// ���Y���ɖ��t���[��0.05������]��ǉ�
	/*transform_.quaRotLocal = Quaternion::Mult(
		transform_.quaRotLocal,
		Quaternion::AngleAxis(AsoUtility::Deg2RadF(0.05f), AsoUtility::AXIS_Y));*/

	transform_.Update();
}

void SkyDome::Draw(void)
{
	SetUseLighting(FALSE);
	MV1DrawModel(transform_.modelId);
	SetUseLighting(TRUE);
}

void SkyDome::InitLoad(void)
{
	// ���f���ǂݍ���
	transform_.SetModel(resMng_.Load(			// 1�� = Load()  ���� = Depulicate()
		ResourceManager::SRC::SPACE_DOME).handleId_);
}

void SkyDome::InitTransform(void)
{
	transform_.scl = { 0.3f,0.3f,0.3f };

	transform_.quaRot = Quaternion::Identity();
	// X����90�x
	transform_.quaRotLocal = Quaternion::AngleAxis(AsoUtility::Deg2RadF(200.0f), AsoUtility::AXIS_Z);

	// ���W
	transform_.pos = AsoUtility::VECTOR_ZERO;
}

void SkyDome::InitCollider(void)
{
}

void SkyDome::InitAnimation(void)
{
}

void SkyDome::InitPost(void)
{
	transform_.Update();

	// Z�o�b�t�@�������i�˂������΍�j
	MV1SetUseZBuffer(transform_.modelId, true);
	MV1SetWriteZBuffer(transform_.modelId, false);

	// �������
	SceneManager::SCENE_ID sceneId = scnMng_.GetSceneID();
	if (sceneId == SceneManager::SCENE_ID::GAME)
	{
		ChangeState(STATE::FOLLOW);
	}
	else
	{
		ChangeState(STATE::STAY);
	}
}

void SkyDome::ChangeState(STATE state)
{
	// ��ԕύX
	state_ = state;

	// ��Ԃ��Ƃ̏���������
	switch (state_)
	{
	case SkyDome::STATE::NONE:
		ChangeStateNone();
		break;
	case SkyDome::STATE::STAY:
		ChangeStateStay();
		break;
	case SkyDome::STATE::FOLLOW:
		ChangeStateFollow();
		break;
	}
}

void SkyDome::ChangeStateNone(void)
{
}

void SkyDome::ChangeStateStay(void)
{
}

void SkyDome::ChangeStateFollow(void)
{
	// �Ǐ]�J�n
	transform_.pos = followTransform_.pos;
	transform_.Update();
}

void SkyDome::UpdateNone(void)
{
}

void SkyDome::UpdateStay(void)
{
	// Y����]
	Quaternion rot = Quaternion::AngleAxis(
		AsoUtility::Deg2RadF(0.07f), AsoUtility::AXIS_Y);
	transform_.quaRot = transform_.quaRot.Mult(rot);
	transform_.Update();
}

void SkyDome::UpdateFollow(void)
{
	// Y����]
	Quaternion rot = Quaternion::AngleAxis(
		AsoUtility::Deg2RadF(0.03f), AsoUtility::AXIS_Y);
	transform_.quaRot = transform_.quaRot.Mult(rot);

	// �Ǐ]
	transform_.pos = followTransform_.pos;

	transform_.Update();
}
