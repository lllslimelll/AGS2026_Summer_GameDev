#include "../../../../Utility/AsoUtility.h"
#include "../../../../Manager/ResourceManager.h"
#include "../../../../Scene/SceneManager.h"
#include "../../../Common/AnimationController.h"
#include "../../../Collider/ColliderLine.h"
#include "../../../Collider/ColliderCapsule.h"
#include "../../../Collider/ColliderSphere.h"
#include "../../../Collider/ColliderModel.h"
#include "../Player.h"
#include "EnemyGiant.h"

EnemyGiant::EnemyGiant(const EnemyBase::EnemyData& data, Player& player)
    :
    EnemyBase(data, player),
    state_(STATE::NONE),
    step_(0.0f),
    activeWayPointIndex_(0),
    nextWayPoint_(AsoUtility::VECTOR_ZERO),
    attackHit_(false)
{
}

EnemyGiant::~EnemyGiant(void)
{
}

void EnemyGiant::InitLoad(void)
{
    transform_.SetModel(
        resMng_.LoadModelDuplicate(ResourceManager::SRC::ENEMY_GIANT));

    viewRangeTransform_.SetModel(
        resMng_.LoadModelDuplicate(ResourceManager::SRC::VIEW_RANGE));
}

void EnemyGiant::InitTransform(void)
{
    transform_.scl = VScale(AsoUtility::VECTOR_ONE, SCALE);
    transform_.quaRot = Quaternion();
    transform_.quaRotLocal = Quaternion::Euler(DEFAULT_LOCAL_ROT);
    transform_.pos = defaultPos_;
    transform_.Update();

    viewRangeTransform_.scl = VIEW_RANGE_SCL;
    viewRangeTransform_.pos =
        MV1GetFramePosition(transform_.modelId, VIEW_RANGE_SYNC_FRAME);
    viewRangeTransform_.quaRot =
        transform_.quaRot.Mult(
            Quaternion::AngleAxis(VIEW_RANGE_ROT_X, AsoUtility::AXIS_X));
    viewRangeTransform_.quaRotLocal =
        Quaternion::AngleAxis(VIEW_RANGE_LOCAL_ROT_X, AsoUtility::AXIS_X);
    viewRangeTransform_.Update();
}

void EnemyGiant::InitCollider(void)
{
    // �n�ʏՓ˗p����
    ColliderLine* colLine = new ColliderLine(
        ColliderBase::TAG::ENEMY, &transform_,
        COL_LINE_START_LOCAL_POS, COL_LINE_END_LOCAL_POS);
    ownColliders_.emplace(static_cast<int>(COLLIDER_TYPE::GROUND_LINE), colLine);

    // �{�̃J�v�Z��
    ColliderCapsule* colCapsule = new ColliderCapsule(
        ColliderBase::TAG::ENEMY, &transform_,
        COL_CAPSULE_TOP_LOCAL_POS, COL_CAPSULE_DOWN_LOCAL_POS,
        COL_CAPSULE_RADIUS);
    ownColliders_.emplace(static_cast<int>(COLLIDER_TYPE::CAPSULE), colCapsule);

    // ���샂�f���R���C�_
    MV1SetupCollInfo(viewRangeTransform_.modelId);
    ColliderModel* colView =
        new ColliderModel(ColliderBase::TAG::VIEW_RANGE, &viewRangeTransform_);
    ownColliders_.emplace(static_cast<int>(COLLIDER_TYPE::VIEW_RANGE), colView);
}

void EnemyGiant::InitAnimation(void)
{
    animCtrl_ = new AnimationController(transform_.modelId);
    animCtrl_->SetBlendTime(0.2f);

    animCtrl_->Add(static_cast<int>(ANIM_TYPE::IDLE), 20.0f,
        resMng_.Load(ResourceManager::SRC::IDLE).path_);
    animCtrl_->Add(static_cast<int>(ANIM_TYPE::WALK), 25.0f,
        resMng_.Load(ResourceManager::SRC::RUN).path_);
    animCtrl_->Add(static_cast<int>(ANIM_TYPE::RUN), 30.0f,
        resMng_.Load(ResourceManager::SRC::FAST_RUN).path_);
    animCtrl_->Add(static_cast<int>(ANIM_TYPE::ATTACK), 35.0f,
        resMng_.Load(ResourceManager::SRC::ATTACK2).path_);

    animCtrl_->Play(static_cast<int>(ANIM_TYPE::IDLE), true);
}

void EnemyGiant::InitPost(void)
{
    stateChanges_.emplace(static_cast<int>(STATE::NONE),
        std::bind(&EnemyGiant::ChangeStateNone, this));
    stateChanges_.emplace(static_cast<int>(STATE::THINK),
        std::bind(&EnemyGiant::ChangeStateThink, this));
    stateChanges_.emplace(static_cast<int>(STATE::IDLE),
        std::bind(&EnemyGiant::ChangeStateIdle, this));
    stateChanges_.emplace(static_cast<int>(STATE::PATROL),
        std::bind(&EnemyGiant::ChangeStatePatrol, this));
    stateChanges_.emplace(static_cast<int>(STATE::CHASE),
        std::bind(&EnemyGiant::ChangeStateChase, this));
    stateChanges_.emplace(static_cast<int>(STATE::ATTACK),
        std::bind(&EnemyGiant::ChangeStateAttack, this));
    stateChanges_.emplace(static_cast<int>(STATE::RETURN),
        std::bind(&EnemyGiant::ChangeStateReturn, this));
    stateChanges_.emplace(static_cast<int>(STATE::END),
        std::bind(&EnemyGiant::ChangeStateEnd, this));

    // ���񃋁[�g�iCSV��defaultPos���N�_�ɐݒ�j
    wayPoints_.emplace_back(defaultPos_);
    VECTOR p2 = defaultPos_;
    p2.x += movableRange_;   
    wayPoints_.emplace_back(p2);
    VECTOR p3 = defaultPos_;
    p3.z += movableRange_;
    wayPoints_.emplace_back(p3);

    ChangeState(STATE::THINK);
}

void EnemyGiant::UpdateProcess(void)
{
    stateUpdate_();
}

void EnemyGiant::UpdateProcessPost(void)
{
    EnemyBase::UpdateProcessPost();

    // ���샂�f������
    viewRangeTransform_.pos =
        MV1GetFramePosition(transform_.modelId, VIEW_RANGE_SYNC_FRAME);
    viewRangeTransform_.quaRot =
        transform_.quaRot.Mult(
            Quaternion::AngleAxis(VIEW_RANGE_ROT_X, AsoUtility::AXIS_X));
    viewRangeTransform_.Update();

    // �v���C���[�Ƃ̉����߂�
    PushBackFromPlayer();
}

void EnemyGiant::Draw(void)
{
    CharactorBase::Draw();

    // ���샂�f���`��
    SetUseLighting(FALSE);
    MV1DrawModel(viewRangeTransform_.modelId);
    SetUseLighting(TRUE);

#ifdef _DEBUG
    for (const auto& point : wayPoints_)
    {
        DrawSphere3D(point, 30.0f, 10, 0x0000ff, 0x0000ff, false);
    }
#endif
}

// ===== ��ԑJ�� =====

void EnemyGiant::ChangeState(STATE state)
{
    state_ = state;
    CharactorBase::ChangeState(static_cast<int>(state_));
}

void EnemyGiant::ChangeStateNone(void)
{
    stateUpdate_ = std::bind(&EnemyGiant::UpdateNone, this);
}

void EnemyGiant::ChangeStateThink(void)
{
    stateUpdate_ = std::bind(&EnemyGiant::UpdateThink, this);

    int rand = GetRand(100);
    if (rand < 30) { ChangeState(STATE::IDLE); }
    else { ChangeState(STATE::PATROL); }
}

void EnemyGiant::ChangeStateIdle(void)
{
    stateUpdate_ = std::bind(&EnemyGiant::UpdateIdle, this);
    step_ = 2.0f + static_cast<float>(GetRand(3));
    movePow_ = AsoUtility::VECTOR_ZERO;
    animCtrl_->Play(static_cast<int>(ANIM_TYPE::IDLE), true);
}

void EnemyGiant::ChangeStatePatrol(void)
{
    stateUpdate_ = std::bind(&EnemyGiant::UpdatePatrol, this);
    movePow_ = AsoUtility::VECTOR_ZERO;

    if (activeWayPointIndex_ >= (int)wayPoints_.size())
    {
        activeWayPointIndex_ = 0;
        ChangeState(STATE::THINK);
        return;
    }

    nextWayPoint_ = wayPoints_[activeWayPointIndex_];
    SetMoveDirToTarget(nextWayPoint_);
    moveSpeed_ = SPEED_PATROL;
    animCtrl_->Play(static_cast<int>(ANIM_TYPE::WALK), true);
}

void EnemyGiant::ChangeStateChase(void)
{
    stateUpdate_ = std::bind(&EnemyGiant::UpdateChase, this);
    moveSpeed_ = SPEED_CHASE;
    animCtrl_->Play(static_cast<int>(ANIM_TYPE::RUN), true);
}

void EnemyGiant::ChangeStateAttack(void)
{
    stateUpdate_ = std::bind(&EnemyGiant::UpdateAttack, this);
    movePow_ = AsoUtility::VECTOR_ZERO;
    attackHit_ = false;
    animCtrl_->Play(static_cast<int>(ANIM_TYPE::ATTACK), false);
}

void EnemyGiant::ChangeStateReturn(void)
{
    stateUpdate_ = std::bind(&EnemyGiant::UpdateReturn, this);
    activeWayPointIndex_ = 0;
    nextWayPoint_ = wayPoints_[0];
    SetMoveDirToTarget(nextWayPoint_);
    moveSpeed_ = SPEED_PATROL;
    animCtrl_->Play(static_cast<int>(ANIM_TYPE::WALK), true);
}

void EnemyGiant::ChangeStateEnd(void)
{
    stateUpdate_ = std::bind(&EnemyGiant::UpdateEnd, this);
    //isEnd_ = true;
}

// ===== �X�V�n =====

void EnemyGiant::UpdateNone(void)
{
}

void EnemyGiant::UpdateThink(void)
{
}

void EnemyGiant::UpdateIdle(void)
{
    step_ -= scnMng_.GetDeltaTime();
    if (step_ < 0.0f)
    {
        ChangeState(STATE::THINK);
        return;
    }

    if (InSearchConeModel())
    {
        ChangeState(STATE::CHASE);
    }
}

void EnemyGiant::UpdatePatrol(void)
{
    if (AsoUtility::IsHitSphere(transform_.pos, nextWayPoint_, 80.0f))
    {
        activeWayPointIndex_++;
        ChangeState(STATE::THINK);
        return;
    }

    SetMoveDirToTarget(nextWayPoint_);
    movePow_ = VScale(moveDir_, moveSpeed_);

    if (InSearchConeModel())
    {
        ChangeState(STATE::CHASE);
    }
}

void EnemyGiant::UpdateChase(void)
{
    float dist = DistToPlayer();

    // �U���������ɓ�������U��
    if (dist <= DIST_ATTACK)
    {
        ChangeState(STATE::ATTACK);
        return;
    }

    // �ǐՉ��������𒴂�����A��
    if (dist > DIST_CHASE)
    {
        ChangeState(STATE::RETURN);
        return;
    }

    // �v���C���[�Ɍ������Ĉړ�
    SetMoveDirToTarget(player_.GetTransform().pos);
    movePow_ = VScale(moveDir_, moveSpeed_);
}

void EnemyGiant::UpdateAttack(void)
{
    // �U���A�j���[�V�����I���Ŏ��̏�Ԃ�
    if (animCtrl_->IsEnd())
    {
        float dist = DistToPlayer();
        if (dist <= DIST_ATTACK)
        {
            ChangeState(STATE::ATTACK);  // �A���U��
        }
        else if (dist > DIST_CHASE)
        {
            ChangeState(STATE::RETURN);
        }
        else
        {
            ChangeState(STATE::CHASE);
        }
        return;
    }

    // ��t���[���̋��̃R���C�_�ƃv���C���[�J�v�Z���̓����蔻��
    if (!attackHit_)
    {
        // ��t���[���̃��[���h���W�擾
        VECTOR handPos = MV1GetFramePosition(transform_.modelId, ATTACK_HAND_FRAME);

        for (const auto& hitCol : hitColliders_)
        {
            if (hitCol->GetTag() != ColliderBase::TAG::PLAYER) continue;

            const ColliderCapsule* playerCapsule =
                dynamic_cast<const ColliderCapsule*>(hitCol);
            if (playerCapsule == nullptr) continue;

            // ��̋��̂ƃv���C���[�J�v�Z���̓����蔻��
            VECTOR capTop = playerCapsule->GetPosTop();
            VECTOR capDown = playerCapsule->GetPosDown();
            float  capR = playerCapsule->GetRadius();

            if (AsoUtility::IsHitSphereCapsule(
                handPos, ATTACK_SPHERE_RADIUS,
                capTop, capDown, capR))
            {
                player_.OnDamaged(static_cast<int>(ATTACK_DAMAGE));
                attackHit_ = true;
                break;
            }
        }
    }
}

void EnemyGiant::UpdateReturn(void)
{
    if (AsoUtility::IsHitSphere(transform_.pos, wayPoints_[0], 80.0f))
    {
        ChangeState(STATE::THINK);
        return;
    }

    SetMoveDirToTarget(wayPoints_[0]);
    movePow_ = VScale(moveDir_, moveSpeed_);

    // �A�Ғ����v���C���[���߂Â��Ă�����ǂ�������
    if (InSearchConeModel())
    {
        ChangeState(STATE::CHASE);
    }
}

void EnemyGiant::UpdateEnd(void)
{
}

// ===== �w���p�[ =====

void EnemyGiant::SetMoveDirToTarget(const VECTOR& target)
{
    VECTOR tmpTarget = target;
    tmpTarget.y = 0.0f;
    VECTOR pos = transform_.pos;
    pos.y = 0.0f;
    moveDir_ = VNorm(VSub(tmpTarget, pos));
    faceDir_ = moveDir_;
}

bool EnemyGiant::InSearchConeModel(void)
{
    int viewRangeType = static_cast<int>(COLLIDER_TYPE::VIEW_RANGE);
    if (ownColliders_.count(viewRangeType) == 0) return false;

    ColliderModel* colliderModel =
        dynamic_cast<ColliderModel*>(ownColliders_.at(viewRangeType));
    if (colliderModel == nullptr) return false;

    MV1RefreshCollInfo(colliderModel->GetFollow()->modelId);

    for (const auto& hitCol : hitColliders_)
    {
        if (hitCol->GetTag() != ColliderBase::TAG::PLAYER) continue;

        const ColliderCapsule* colCapsule =
            dynamic_cast<const ColliderCapsule*>(hitCol);
        if (colCapsule == nullptr) continue;

        if (colCapsule->IsHit(colliderModel, false, false))
        {
            return true;
        }
    }
    return false;
}

float EnemyGiant::DistToPlayer(void) const
{
    return VSize(VSub(player_.GetTransform().pos, transform_.pos));
}

void EnemyGiant::PushBackFromPlayer(void)
{
    // ���g�̃J�v�Z���R���C�_�擾
    int capsuleType = static_cast<int>(COLLIDER_TYPE::CAPSULE);
    if (ownColliders_.count(capsuleType) == 0) return;

    ColliderCapsule* myCapsule =
        dynamic_cast<ColliderCapsule*>(ownColliders_.at(capsuleType));
    if (myCapsule == nullptr) return;

    // �v���C���[�̃J�v�Z���R���C�_�Ɣ�r
    for (const auto& hitCol : hitColliders_)
    {
        if (hitCol->GetTag() != ColliderBase::TAG::PLAYER) continue;

        const ColliderCapsule* playerCapsule =
            dynamic_cast<const ColliderCapsule*>(hitCol);
        if (playerCapsule == nullptr) continue;

        // �J�v�Z���Ԃ̒��S���m�̃x�N�g��
        VECTOR myCenter = VScale(VAdd(myCapsule->GetPosTop(), myCapsule->GetPosDown()), 0.5f);
        VECTOR plCenter = VScale(VAdd(playerCapsule->GetPosTop(), playerCapsule->GetPosDown()), 0.5f);

        float dist = VSize(VSub(myCenter, plCenter));
        float minDist = myCapsule->GetRadius() + playerCapsule->GetRadius();

        if (dist < minDist && dist > 0.01f)
        {
            // �����߂������i�v���C���[���痣�������j
            VECTOR pushDir = VNorm(VSub(myCenter, plCenter));
            float  overlap = minDist - dist;
            transform_.pos = VAdd(transform_.pos, VScale(pushDir, overlap * 0.5f));
            transform_.Update();
        }
        break;
    }
}