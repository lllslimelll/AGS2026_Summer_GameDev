#include <cmath>
#include <random>
#include "../../../../Utility/AsoUtility.h"
#include "../../../../Manager/ResourceManager.h"
#include "../../../../Scene/SceneManager.h"
#include "../../../../Manager/SoundManager.h"
#include "../../../Common/AnimationController.h"
#include "../../../Collider/ColliderLine.h"
#include "../../../Collider/ColliderCapsule.h"
#include "../../../Collider/ColliderSphere.h"
#include "../../../Collider/ColliderModel.h"
#include "../Player.h"
#include "EnemyGiant.h"

EnemyGiant::EnemyGiant(const EnemyBase::EnemyData& data, Player& player)
    :
    EnemyBase(data, player),
    state_(STATE::NONE),
    attackHit_(false),
    attackHandFrame_(-1),
    isAware_(false),
    wanderDir_(AsoUtility::DIR_F),
    wanderTimer_(0.0f),
    idleTimer_(0.0f),
    // �C���X�^���X�ŗL�V�[�h�Fthis �̃A�h���X�� XOR ����
    // �����̂����t���[���Ő�������Ă����Ȃ��悤�ɂ���
    rng_(std::random_device{}() ^ static_cast<unsigned>(
        reinterpret_cast<uintptr_t>(this))),
    wallNormalXZ_(AsoUtility::VECTOR_ZERO),
    prevMoveDir_(AsoUtility::DIR_F),
    lastAvoidChoice_(0),
    avoidCommitTimer_(0.0f),
    stuckTimer_(0.0f),
    stuckLastPos_(AsoUtility::VECTOR_ZERO)
{
}

EnemyGiant::~EnemyGiant(void) {}

// ---------------------------------------------------------------
// ������
// ---------------------------------------------------------------
void EnemyGiant::InitLoad(void)
{
    transform_.SetModel(
        resMng_.LoadModelDuplicate(ResourceManager::SRC::ENEMY_GIANT));
}

void EnemyGiant::InitTransform(void)
{
    transform_.scl = VScale(AsoUtility::VECTOR_ONE, SCALE);
    transform_.quaRot = Quaternion();
    transform_.quaRotLocal = Quaternion::Euler(DEFAULT_LOCAL_ROT);
    transform_.pos = defaultPos_;
    transform_.Update();
}

void EnemyGiant::InitCollider(void)
{
    ColliderLine* colLine = new ColliderLine(
        ColliderBase::TAG::ENEMY, &transform_,
        COL_LINE_START_LOCAL_POS, COL_LINE_END_LOCAL_POS);
    ownColliders_.emplace(static_cast<int>(COLLIDER_TYPE::GROUND_LINE), colLine);

    ColliderCapsule* colCapsule = new ColliderCapsule(
        ColliderBase::TAG::ENEMY, &transform_,
        COL_CAPSULE_TOP_LOCAL_POS, COL_CAPSULE_DOWN_LOCAL_POS,
        COL_CAPSULE_RADIUS);
    ownColliders_.emplace(static_cast<int>(COLLIDER_TYPE::CAPSULE), colCapsule);
}

void EnemyGiant::InitAnimation(void)
{
    animCtrl_ = new AnimationController(transform_.modelId);
    animCtrl_->SetBlendTime(0.2f);

    animCtrl_->Add(static_cast<int>(ANIM_TYPE::IDLE), 20.0f,
        resMng_.Load(ResourceManager::SRC::IDLE).path_);
    animCtrl_->Add(static_cast<int>(ANIM_TYPE::WALK), 25.0f,
        resMng_.Load(ResourceManager::SRC::RUN).path_);
    animCtrl_->Add(static_cast<int>(ANIM_TYPE::RUN), 30.0f,
        resMng_.Load(ResourceManager::SRC::FAST_RUN).path_);
    animCtrl_->Add(static_cast<int>(ANIM_TYPE::ATTACK), 200.0f,
        resMng_.Load(ResourceManager::SRC::ATTACK).path_);

    animCtrl_->Play(static_cast<int>(ANIM_TYPE::IDLE), true);
}

void EnemyGiant::InitPost(void)
{
    stateChanges_.emplace(static_cast<int>(STATE::NONE),
        std::bind(&EnemyGiant::ChangeStateNone, this));
    stateChanges_.emplace(static_cast<int>(STATE::IDLE),
        std::bind(&EnemyGiant::ChangeStateIdle, this));
    stateChanges_.emplace(static_cast<int>(STATE::WANDER),
        std::bind(&EnemyGiant::ChangeStateWander, this));
    stateChanges_.emplace(static_cast<int>(STATE::CHASE),
        std::bind(&EnemyGiant::ChangeStateChase, this));
    stateChanges_.emplace(static_cast<int>(STATE::ATTACK),
        std::bind(&EnemyGiant::ChangeStateAttack, this));
    stateChanges_.emplace(static_cast<int>(STATE::END),
        std::bind(&EnemyGiant::ChangeStateEnd, this));

    attackHandFrame_ = MV1SearchFrame(transform_.modelId, "mixamorig:LeftHand");

    ChangeState(STATE::WANDER);

    InitCurvatureShaderSkinned();
}

// ---------------------------------------------------------------
// �X�V
// ---------------------------------------------------------------
void EnemyGiant::UpdateProcess(void)
{
    stateUpdate_();
}

void EnemyGiant::UpdateProcessPost(void)
{
    EnemyBase::UpdateProcessPost();

    // �����߂���̈ʒu����ǖ@���𐄒�i���t���[���� ApplyWallSlide �p�j
    UpdateWallNormal();

    PushBackFromPlayer();
}

void EnemyGiant::Draw(void)
{
    EnemyBase::Draw();

#ifdef _DEBUG
    if (attackHandFrame_ >= 0)
    {
        DrawSphere3D(GetAttackSpherePos(), ATTACK_SPHERE_RADIUS,
            16, 0xff0000, 0xff0000, false);
    }
    if (debugDrawView_) DrawDebugAI();
#endif
}

// ===============================================================
// ��ԑJ��
// ===============================================================
void EnemyGiant::ChangeState(STATE state)
{
    state_ = state;
    CharactorBase::ChangeState(static_cast<int>(state_));
}

void EnemyGiant::ChangeStateNone(void)
{
    stateUpdate_ = std::bind(&EnemyGiant::UpdateNone, this);
}

void EnemyGiant::ChangeStateIdle(void)
{
    stateUpdate_ = std::bind(&EnemyGiant::UpdateIdle, this);

    idleTimer_ = RandFloat(IDLE_TIME_MIN, IDLE_TIME_MAX);

    movePow_ = AsoUtility::VECTOR_ZERO;
    animCtrl_->Play(static_cast<int>(ANIM_TYPE::IDLE), true);
    ResetSteering();
}

void EnemyGiant::ChangeStateWander(void)
{
    stateUpdate_ = std::bind(&EnemyGiant::UpdateWander, this);

    // �V���������_�������Ǝ��Ԃ�I��
    PickNewWanderDirection();

    // �O�����ǂ����Ă�����󂢂Ă�����ɐU�蒼��
    if (!IsDirectionClear(wanderDir_)) ReorientToClearDirection();

    moveDir_ = wanderDir_;
    faceDir_ = wanderDir_;

    moveSpeed_ = SPEED_WANDER;
    animCtrl_->Play(static_cast<int>(ANIM_TYPE::WALK), true);
    ResetSteering();
}

void EnemyGiant::ChangeStateChase(void)
{
    stateUpdate_ = std::bind(&EnemyGiant::UpdateChase, this);

    moveSpeed_ = SPEED_CHASE;
    animCtrl_->Play(static_cast<int>(ANIM_TYPE::RUN), true);
    ResetSteering();

    if (!isAware_)
    {
        SoundManager::GetInstance().PlayFound();
        isAware_ = true;
    }
}

void EnemyGiant::ChangeStateAttack(void)
{
    stateUpdate_ = std::bind(&EnemyGiant::UpdateAttack, this);
    movePow_ = AsoUtility::VECTOR_ZERO;
    attackHit_ = false;

    SetMoveDirToTarget(player_.GetTransform().pos);

    if (animCtrl_->GetPlayType() == static_cast<int>(ANIM_TYPE::ATTACK))
        animCtrl_->Replay();
    else
        animCtrl_->Play(static_cast<int>(ANIM_TYPE::ATTACK), false);
}

void EnemyGiant::ChangeStateEnd(void)
{
    stateUpdate_ = std::bind(&EnemyGiant::UpdateEnd, this);
}

// ===============================================================
// �e�X�e�[�g�X�V
// ===============================================================
void EnemyGiant::UpdateNone(void) {}
void EnemyGiant::UpdateEnd(void) {}

void EnemyGiant::UpdateIdle(void)
{
    movePow_ = AsoUtility::VECTOR_ZERO;

    if (IsPlayerInSight())
    {
        ChangeState(STATE::CHASE);
        return;
    }

    idleTimer_ -= scnMng_.GetDeltaTime();
    if (idleTimer_ <= 0.0f)
    {
        ChangeState(STATE::WANDER);
    }
}

// ---------------------------------------------------------------
// �p�j�F�����_�������Ƀ����_�����Ԃ��������B
// �O���ɏ�Q�������m�����������U�蒼���B���Ԑ؂�� IDLE �ցB
// ---------------------------------------------------------------
void EnemyGiant::UpdateWander(void)
{
    if (IsPlayerInSight())
    {
        ChangeState(STATE::CHASE);
        return;
    }

    // ���Ԑ؂�Ȃ�ҋ@��
    wanderTimer_ -= scnMng_.GetDeltaTime();
    if (wanderTimer_ <= 0.0f)
    {
        ChangeState(STATE::IDLE);
        return;
    }

    // ���݂̕������ǂ���Ă�����U�蒼���B
    // ������Ȃ��ꍇ�����t���[���܂������̂ł��̏�ő����݂��邾���B
    if (!IsDirectionClear(wanderDir_))
    {
        if (!ReorientToClearDirection())
        {
            // �ǂ̕������ǂ����Ă���F���̏�ő����� �� �^�C�}�[������ IDLE ��
            movePow_ = AsoUtility::VECTOR_ZERO;
            return;
        }
    }

    // �l�܂���������������I�ɐU�蒼��
    if (IsStuck())
    {
        PickNewWanderDirection();
        ReorientToClearDirection();
    }

    moveDir_ = wanderDir_;
    faceDir_ = wanderDir_;

    ApplyWallSlide();
    LimitTurnRate();
    movePow_ = VScale(moveDir_, moveSpeed_);
}

void EnemyGiant::UpdateChase(void)
{
    float dist = DistToPlayer();

    // ���������F���̏�Ŝp�j�ɖ߂�i���W�������Ȃ��̂œ��ʂȏ����s�v�j
    if (dist > DIST_LOSE_CHASE)
    {
        isAware_ = false;
        ChangeState(STATE::WANDER);
        return;
    }

    if (dist <= DIST_ATTACK)
    {
        ChangeState(STATE::ATTACK);
        return;
    }

    VECTOR dir = ComputeChaseDir();
    moveDir_ = dir;
    faceDir_ = dir;

    ApplyWallSlide();
    LimitTurnRate();
    movePow_ = VScale(moveDir_, moveSpeed_);
}

void EnemyGiant::UpdateAttack(void)
{
    const auto& anim = animCtrl_->GetPlayAnim();
    float progress = (anim.totalTime > 0.0f) ? (anim.step / anim.totalTime) : 0.0f;

    bool hitboxActive =
        !attackHit_ &&
        progress >= ATTACK_HIT_START &&
        progress <= ATTACK_HIT_END;

    if (hitboxActive)
    {
        VECTOR spherePos = GetAttackSpherePos();

        for (const auto& hitCol : hitColliders_)
        {
            if (hitCol->GetTag() != ColliderBase::TAG::PLAYER) continue;

            const ColliderCapsule* playerCapsule =
                dynamic_cast<const ColliderCapsule*>(hitCol);
            if (playerCapsule == nullptr) continue;

            if (AsoUtility::IsHitSphereCapsule(
                spherePos, ATTACK_SPHERE_RADIUS,
                playerCapsule->GetPosTop(),
                playerCapsule->GetPosDown(),
                playerCapsule->GetRadius()))
            {
                player_.OnDamagedByEnemy(ATTACK_DAMAGE);
                SoundManager::GetInstance().PlayDamaged();
                attackHit_ = true;
                break;
            }
        }
    }

    if (animCtrl_->IsEnd())
    {
        float dist = DistToPlayer();
        if (dist > DIST_LOSE_CHASE)
        {
            isAware_ = false;                       // �� �ǉ�
            ChangeState(STATE::WANDER);
        }
        else if (dist <= DIST_ATTACK) ChangeState(STATE::ATTACK);
        else                          ChangeState(STATE::CHASE);
    }
}

// ===============================================================
// �w���p�[�F�p�j
// ===============================================================

// �����_���� XZ �����ƃ����_���ȕ��s���Ԃ�ݒ肷��B
//
// �����͋ɍ��W�� �� �� [0, 2��) �𒊑I���A
//   dir = (cos��, 0, sin��)
// �� XZ ���ʏ�̒P�ʃx�N�g�������B
void EnemyGiant::PickNewWanderDirection(void)
{
    float theta = RandAngle();
    wanderDir_.x = cosf(theta);
    wanderDir_.y = 0.0f;
    wanderDir_.z = sinf(theta);

    wanderTimer_ = RandFloat(WANDER_TIME_MIN, WANDER_TIME_MAX);
}

// �w������Ƀ��C���΂��ĎՕ������Ȃ����m�F����B
bool EnemyGiant::IsDirectionClear(const VECTOR& dir) const
{
    VECTOR from = transform_.pos; from.y += EYE_HEIGHT;
    VECTOR to = VAdd(from, VScale(dir, WANDER_PROBE_DIST));

    return !const_cast<EnemyGiant*>(this)->IsOccludedByColliders(from, to);
}

// ���݂� wanderDir_ �����ɍ��E�� WANDER_TURN_STEP_DEG ���U���āA
// �ŏ��ɋ󂢂��������̗p����B
//
// �T������ +�X�e�b�v, -�X�e�b�v, +2�X�e�b�v, -2�X�e�b�v, ...
// ����ŕǂɑ΂��č��E�Ώ̂ɐ��ɒT���̂ŁA
// �u�킸���ɃY���������v��D�悵�đI�ׂ�B
bool EnemyGiant::ReorientToClearDirection(void)
{
    const float stepRad = WANDER_TURN_STEP_DEG * DX_PI_F / 180.0f;

    for (int step = 1; step <= WANDER_TURN_MAX_STEP; ++step)
    {
        // +step ����
        {
            Quaternion rot = Quaternion::AngleAxis(+stepRad * step, AsoUtility::AXIS_Y);
            VECTOR cand = rot.PosAxis(wanderDir_);
            if (IsDirectionClear(cand))
            {
                wanderDir_ = cand;
                return true;
            }
        }
        // -step ����
        {
            Quaternion rot = Quaternion::AngleAxis(-stepRad * step, AsoUtility::AXIS_Y);
            VECTOR cand = rot.PosAxis(wanderDir_);
            if (IsDirectionClear(cand))
            {
                wanderDir_ = cand;
                return true;
            }
        }
    }

    return false;
}

// ===============================================================
// �w���p�[�F����
// ===============================================================

// std::mt19937�i�����Z���k�E�c�C�X�^�j
// �C���X�^���X�ŗL�V�[�h�œƗ���������������B
float EnemyGiant::RandFloat(float minVal, float maxVal)
{
    std::uniform_real_distribution<float> dist(minVal, maxVal);
    return dist(rng_);
}

float EnemyGiant::RandAngle(void)
{
    return RandFloat(0.0f, 2.0f * DX_PI_F);
}

// ===============================================================
// �w���p�[�F�ړ��ƕ���
// ===============================================================
void EnemyGiant::SetMoveDirToTarget(const VECTOR& target)
{
    VECTOR dir = VSub(target, transform_.pos);
    dir.y = 0.0f;
    if (VSize(dir) < 0.01f) return;

    moveDir_ = VNorm(dir);
    faceDir_ = moveDir_;
}

float EnemyGiant::DistToPlayer(void) const
{
    return VSize(VSub(player_.GetTransform().pos, transform_.pos));
}

float EnemyGiant::DistToPlayerXZ(void) const
{
    VECTOR d = VSub(player_.GetTransform().pos, transform_.pos);
    d.y = 0.0f;
    return VSize(d);
}

bool EnemyGiant::IsPlayerInSight(void)
{
    VECTOR myPos = transform_.pos;
    VECTOR plPos = player_.GetTransform().pos;

    VECTOR toPl = VSub(plPos, myPos);
    toPl.y = 0.0f;
    float dist = VSize(toPl);

    if (dist > VIEW_RANGE) return false;
    if (dist < 0.0001f)    return true;

    VECTOR toPlDir = VScale(toPl, 1.0f / dist);

    VECTOR fwd = faceDir_;
    fwd.y = 0.0f;
    if (VSize(fwd) < 0.0001f) return false;
    fwd = VNorm(fwd);

    float cosAngle = VDot(fwd, toPlDir);
    float cosHalfFov = cosf(VIEW_HALF_FOV_RAD);
    if (cosAngle < cosHalfFov) return false;

    VECTOR eye = myPos; eye.y += EYE_HEIGHT;
    VECTOR chest = plPos; chest.y += EYE_HEIGHT;
    if (IsOccludedByColliders(eye, chest)) return false;

    return true;
}

// ---------------------------------------------------------------
// �ǐՕ����̌���i���C�L���X�g�{�q�X�e���V�X�j
// ---------------------------------------------------------------
VECTOR EnemyGiant::ComputeChaseDir(void)
{
    VECTOR myPos = transform_.pos;
    VECTOR plPos = player_.GetTransform().pos;

    VECTOR base = VSub(plPos, myPos);
    base.y = 0.0f;
    float baseLen = VSize(base);
    if (baseLen < 0.001f) return faceDir_;
    base = VScale(base, 1.0f / baseLen);

    VECTOR probeFrom = myPos; probeFrom.y += EYE_HEIGHT;

    auto probe = [&](const VECTOR& dir) -> bool {
        VECTOR to = VAdd(probeFrom, VScale(dir, AVOID_PROBE_DIST));
        return IsOccludedByColliders(probeFrom, to);
        };

    Quaternion rotL = Quaternion::AngleAxis(+AVOID_ANGLE_RAD, AsoUtility::AXIS_Y);
    Quaternion rotR = Quaternion::AngleAxis(-AVOID_ANGLE_RAD, AsoUtility::AXIS_Y);
    VECTOR dirL = rotL.PosAxis(base);
    VECTOR dirR = rotR.PosAxis(base);

    bool blockedFwd = probe(base);

    // �q�X�e���V�X
    if (avoidCommitTimer_ > 0.0f)
    {
        avoidCommitTimer_ -= scnMng_.GetDeltaTime();

        if (lastAvoidChoice_ == 0 && !blockedFwd)  return base;
        if (lastAvoidChoice_ == -1 && !probe(dirL)) return dirL;
        if (lastAvoidChoice_ == +1 && !probe(dirR)) return dirR;
    }

    auto commit = [&](int choice, const VECTOR& dir) -> VECTOR {
        lastAvoidChoice_ = choice;
        avoidCommitTimer_ = AVOID_COMMIT_SEC;
        return dir;
        };

    if (!blockedFwd) return commit(0, base);

    bool blockedL = probe(dirL);
    bool blockedR = probe(dirR);

    if (!blockedL && !blockedR)
    {
        VECTOR endL = VAdd(myPos, VScale(dirL, AVOID_PROBE_DIST));
        VECTOR endR = VAdd(myPos, VScale(dirR, AVOID_PROBE_DIST));
        float  dL = VSize(VSub(plPos, endL));
        float  dR = VSize(VSub(plPos, endR));
        return (dL <= dR) ? commit(-1, dirL) : commit(+1, dirR);
    }
    if (!blockedL) return commit(-1, dirL);
    if (!blockedR) return commit(+1, dirR);

    VECTOR dirWL = Quaternion::AngleAxis(+AVOID_ANGLE_WIDE_RAD, AsoUtility::AXIS_Y).PosAxis(base);
    VECTOR dirWR = Quaternion::AngleAxis(-AVOID_ANGLE_WIDE_RAD, AsoUtility::AXIS_Y).PosAxis(base);

    if (!probe(dirWL)) return commit(-1, dirWL);
    if (!probe(dirWR)) return commit(+1, dirWR);

    return commit(0, base);
}

void EnemyGiant::PushBackFromPlayer(void)
{
    int capsuleType = static_cast<int>(COLLIDER_TYPE::CAPSULE);
    if (ownColliders_.count(capsuleType) == 0) return;

    ColliderCapsule* myCapsule =
        dynamic_cast<ColliderCapsule*>(ownColliders_.at(capsuleType));
    if (myCapsule == nullptr) return;

    for (const auto& hitCol : hitColliders_)
    {
        if (hitCol->GetTag() != ColliderBase::TAG::PLAYER) continue;

        const ColliderCapsule* playerCapsule =
            dynamic_cast<const ColliderCapsule*>(hitCol);
        if (playerCapsule == nullptr) continue;

        VECTOR myC = myCapsule->GetCenter();
        VECTOR plC = playerCapsule->GetCenter();

        float dx = myC.x - plC.x;
        float dz = myC.z - plC.z;
        float distSq = dx * dx + dz * dz;

        float minDist = myCapsule->GetRadius() + playerCapsule->GetRadius();
        if (distSq >= minDist * minDist) return;

        float dist = sqrtf(distSq);
        if (dist < 0.0001f) { dx = 1.0f; dz = 0.0f; dist = 1.0f; }

        float k = (minDist - dist) * 0.5f / dist;
        transform_.pos.x += dx * k;
        transform_.pos.z += dz * k;
        transform_.Update();
        return;
    }
}

VECTOR EnemyGiant::GetAttackSpherePos(void) const
{
    VECTOR framePos = MV1GetFramePosition(transform_.modelId, attackHandFrame_);
    VECTOR worldOffset = transform_.quaRot.PosAxis(ATTACK_SPHERE_OFFSET_LOCAL);
    return VAdd(framePos, worldOffset);
}

// ===============================================================
// �X�e�A�����O�t�B���^
// ===============================================================
void EnemyGiant::UpdateWallNormal(void)
{
    VECTOR expected = VAdd(prevPos_, movePow_);

    float pdx = transform_.pos.x - expected.x;
    float pdz = transform_.pos.z - expected.z;
    float pushLen = sqrtf(pdx * pdx + pdz * pdz);

    if (pushLen < WALL_PUSH_EPSILON)
    {
        wallNormalXZ_ = AsoUtility::VECTOR_ZERO;
        return;
    }

    float inv = 1.0f / pushLen;
    wallNormalXZ_.x = pdx * inv;
    wallNormalXZ_.y = 0.0f;
    wallNormalXZ_.z = pdz * inv;
}

// v_slide = v - (v�En)n
void EnemyGiant::ApplyWallSlide(void)
{
    if (VSize(wallNormalXZ_) < 0.0001f) return;

    float vn = VDot(moveDir_, wallNormalXZ_);
    if (vn >= 0.0f) return;

    moveDir_ = VSub(moveDir_, VScale(wallNormalXZ_, vn));

    float len = VSize(moveDir_);
    if (len > 0.0001f)
    {
        moveDir_ = VScale(moveDir_, 1.0f / len);
    }
    else
    {
        // �ǖ@���� 90 �x��]�����ڐ����̗p
        moveDir_.x = -wallNormalXZ_.z;
        moveDir_.y = 0.0f;
        moveDir_.z = wallNormalXZ_.x;
    }

    faceDir_ = moveDir_;
}

void EnemyGiant::LimitTurnRate(void)
{
    if (VSize(prevMoveDir_) < 0.0001f || VSize(moveDir_) < 0.0001f)
    {
        prevMoveDir_ = moveDir_;
        return;
    }

    VECTOR a = prevMoveDir_; a.y = 0.0f;
    VECTOR b = moveDir_;     b.y = 0.0f;
    float la = VSize(a), lb = VSize(b);
    if (la < 0.0001f || lb < 0.0001f) { prevMoveDir_ = moveDir_; return; }
    a = VScale(a, 1.0f / la);
    b = VScale(b, 1.0f / lb);

    float cosA = VDot(a, b);
    if (cosA > 1.0f) cosA = 1.0f;
    if (cosA < -1.0f) cosA = -1.0f;
    float angle = acosf(cosA);
    float maxAngle = MAX_TURN_RAD_PER_SEC * scnMng_.GetDeltaTime();

    if (angle <= maxAngle)
    {
        prevMoveDir_ = moveDir_;
        faceDir_ = moveDir_;
        return;
    }

    VECTOR cross = VCross(a, b);
    float  sign = (cross.y >= 0.0f) ? +1.0f : -1.0f;

    Quaternion rot = Quaternion::AngleAxis(sign * maxAngle, AsoUtility::AXIS_Y);
    moveDir_ = rot.PosAxis(a);
    faceDir_ = moveDir_;
    prevMoveDir_ = moveDir_;
}

// ===============================================================
// �X�^�b�N���m
// ===============================================================
bool EnemyGiant::IsStuck(void)
{
    float dx = transform_.pos.x - stuckLastPos_.x;
    float dz = transform_.pos.z - stuckLastPos_.z;

    if (dx * dx + dz * dz < STUCK_MOVE_MIN * STUCK_MOVE_MIN)
        stuckTimer_ += scnMng_.GetDeltaTime();
    else
        stuckTimer_ = 0.0f;

    stuckLastPos_ = transform_.pos;

    return stuckTimer_ >= STUCK_TIMEOUT_SEC;
}

void EnemyGiant::ResetSteering(void)
{
    stuckTimer_ = 0.0f;
    stuckLastPos_ = transform_.pos;
    lastAvoidChoice_ = 0;
    avoidCommitTimer_ = 0.0f;
    prevMoveDir_ = moveDir_;
}

// ===============================================================
// �f�o�b�O�`��
// ===============================================================
#ifdef _DEBUG
void EnemyGiant::DrawDebugAI(void)
{
    VECTOR pos = transform_.pos;
    pos.y += EYE_HEIGHT;

    VECTOR fwd = faceDir_;
    fwd.y = 0.0f;
    if (VSize(fwd) < 0.0001f) fwd = AsoUtility::DIR_F;
    fwd = VNorm(fwd);

    // ����~��
    unsigned int viewCol = IsPlayerInSight()
        ? GetColor(255, 40, 40)
        : GetColor(40, 255, 40);

    Quaternion rotL = Quaternion::AngleAxis(+VIEW_HALF_FOV_RAD, AsoUtility::AXIS_Y);
    Quaternion rotR = Quaternion::AngleAxis(-VIEW_HALF_FOV_RAD, AsoUtility::AXIS_Y);
    VECTOR dirL = rotL.PosAxis(fwd);
    VECTOR dirR = rotR.PosAxis(fwd);

    DrawLine3D(pos, VAdd(pos, VScale(fwd, VIEW_RANGE)), viewCol);
    DrawLine3D(pos, VAdd(pos, VScale(dirL, VIEW_RANGE)), viewCol);
    DrawLine3D(pos, VAdd(pos, VScale(dirR, VIEW_RANGE)), viewCol);

    const int SEG = 24;
    VECTOR prev = VAdd(pos, VScale(dirL, VIEW_RANGE));
    for (int i = 1; i <= SEG; ++i)
    {
        float t = static_cast<float>(i) / SEG;
        float ang = -VIEW_HALF_FOV_RAD + 2.0f * VIEW_HALF_FOV_RAD * t;
        VECTOR e = VAdd(pos, VScale(
            Quaternion::AngleAxis(ang, AsoUtility::AXIS_Y).PosAxis(fwd), VIEW_RANGE));
        DrawLine3D(prev, e, viewCol);
        prev = e;
    }

    // �p�j�����ƃv���[�u�����i���F�j
    if (state_ == STATE::WANDER && VSize(wanderDir_) > 0.0001f)
    {
        VECTOR from = transform_.pos; from.y += EYE_HEIGHT;
        VECTOR to = VAdd(from, VScale(wanderDir_, WANDER_PROBE_DIST));
        unsigned int col = IsDirectionClear(wanderDir_)
            ? GetColor(255, 220, 40)   // �ʂ��
            : GetColor(255, 80, 80);  // �ǂ���Ă�
        DrawLine3D(from, to, col);
    }

    // �ǖ@���i�I�����W�j
    if (VSize(wallNormalXZ_) > 0.0001f)
    {
        VECTOR from = transform_.pos; from.y += EYE_HEIGHT;
        DrawLine3D(from, VAdd(from, VScale(wallNormalXZ_, 150.0f)),
            GetColor(255, 128, 0));
    }

    // ���ۂ̐i�s�����i���F�j
    if (VSize(moveDir_) > 0.0001f)
    {
        VECTOR from = transform_.pos; from.y += EYE_HEIGHT + 20.0f;
        DrawLine3D(from, VAdd(from, VScale(moveDir_, 200.0f)),
            GetColor(0, 255, 255));
    }
}
#endif