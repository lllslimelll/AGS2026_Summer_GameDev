#include <cmath>
#include "../../../../Utility/AsoUtility.h"
#include "../../../../Manager/ResourceManager.h"
#include "../../../../Scene/SceneManager.h"
#include "../../../../Manager/SoundManager.h"
#include "../../../Common/AnimationController.h"
#include "../../../Collider/ColliderLine.h"
#include "../../../Collider/ColliderCapsule.h"
#include "../../../Collider/ColliderSphere.h"
#include "../../../Collider/ColliderModel.h"
#include "../Player.h"
#include "EnemyGiant.h"

EnemyGiant::EnemyGiant(const EnemyBase::EnemyData& data, Player& player)
    :
    EnemyBase(data, player),
    state_(STATE::NONE),
    idleTimer_(0.0f),
    attackHit_(false),
    attackHandFrame_(-1),
    wanderCenter_(data.defaultPos),
    wanderTarget_(data.defaultPos),
    wallNormalXZ_(AsoUtility::VECTOR_ZERO),
    prevMoveDir_(AsoUtility::DIR_F),
    lastAvoidChoice_(0),
    avoidCommitTimer_(0.0f),
    stuckTimer_(0.0f),
    stuckLastPos_(AsoUtility::VECTOR_ZERO)
{
}

EnemyGiant::~EnemyGiant(void) {}

// ---------------------------------------------------------------
// ������
// ---------------------------------------------------------------
void EnemyGiant::InitLoad(void)
{
    transform_.SetModel(
        resMng_.LoadModelDuplicate(ResourceManager::SRC::ENEMY_GIANT));
}

void EnemyGiant::InitTransform(void)
{
    transform_.scl = VScale(AsoUtility::VECTOR_ONE, SCALE);
    transform_.quaRot = Quaternion();
    transform_.quaRotLocal = Quaternion::Euler(DEFAULT_LOCAL_ROT);
    transform_.pos = defaultPos_;
    transform_.Update();
}

void EnemyGiant::InitCollider(void)
{
    ColliderLine* colLine = new ColliderLine(
        ColliderBase::TAG::ENEMY, &transform_,
        COL_LINE_START_LOCAL_POS, COL_LINE_END_LOCAL_POS);
    ownColliders_.emplace(static_cast<int>(COLLIDER_TYPE::GROUND_LINE), colLine);

    ColliderCapsule* colCapsule = new ColliderCapsule(
        ColliderBase::TAG::ENEMY, &transform_,
        COL_CAPSULE_TOP_LOCAL_POS, COL_CAPSULE_DOWN_LOCAL_POS,
        COL_CAPSULE_RADIUS);
    ownColliders_.emplace(static_cast<int>(COLLIDER_TYPE::CAPSULE), colCapsule);
}

void EnemyGiant::InitAnimation(void)
{
    animCtrl_ = new AnimationController(transform_.modelId);
    animCtrl_->SetBlendTime(0.2f);

    animCtrl_->Add(static_cast<int>(ANIM_TYPE::IDLE), 20.0f,
        resMng_.Load(ResourceManager::SRC::IDLE).path_);
    animCtrl_->Add(static_cast<int>(ANIM_TYPE::WALK), 25.0f,
        resMng_.Load(ResourceManager::SRC::RUN).path_);
    animCtrl_->Add(static_cast<int>(ANIM_TYPE::RUN), 30.0f,
        resMng_.Load(ResourceManager::SRC::FAST_RUN).path_);
    animCtrl_->Add(static_cast<int>(ANIM_TYPE::ATTACK), 200.0f,
        resMng_.Load(ResourceManager::SRC::ATTACK).path_);

    animCtrl_->Play(static_cast<int>(ANIM_TYPE::IDLE), true);
}

void EnemyGiant::InitPost(void)
{
    stateChanges_.emplace(static_cast<int>(STATE::NONE),
        std::bind(&EnemyGiant::ChangeStateNone, this));
    stateChanges_.emplace(static_cast<int>(STATE::IDLE),
        std::bind(&EnemyGiant::ChangeStateIdle, this));
    stateChanges_.emplace(static_cast<int>(STATE::WANDER),
        std::bind(&EnemyGiant::ChangeStateWander, this));
    stateChanges_.emplace(static_cast<int>(STATE::CHASE),
        std::bind(&EnemyGiant::ChangeStateChase, this));
    stateChanges_.emplace(static_cast<int>(STATE::ATTACK),
        std::bind(&EnemyGiant::ChangeStateAttack, this));
    stateChanges_.emplace(static_cast<int>(STATE::END),
        std::bind(&EnemyGiant::ChangeStateEnd, this));

    attackHandFrame_ = MV1SearchFrame(transform_.modelId, "mixamorig:LeftHand");

    // �����̜p�j���S�� defaultPos_
    wanderCenter_ = defaultPos_;
    PickNextWanderTarget();

    ChangeState(STATE::WANDER);

    InitCurvatureShaderSkinned();
}

// ---------------------------------------------------------------
// �X�V
// ---------------------------------------------------------------
void EnemyGiant::UpdateProcess(void)
{
    stateUpdate_();
}

void EnemyGiant::UpdateProcessPost(void)
{
    EnemyBase::UpdateProcessPost();

    // �����߂���̈ʒu����ǖ@���𐄒�i���t���[���� ApplyWallSlide �p�j
    UpdateWallNormal();

    // �v���C���[�Ƃ̉����߂�
    PushBackFromPlayer();
}

void EnemyGiant::Draw(void)
{
    EnemyBase::Draw();

#ifdef _DEBUG
    if (attackHandFrame_ >= 0)
    {
        VECTOR spherePos = GetAttackSpherePos();
        DrawSphere3D(spherePos, ATTACK_SPHERE_RADIUS, 16, 0xff0000, 0xff0000, false);
    }
    if (debugDrawView_) DrawDebugAI();
#endif
}

// ===============================================================
// ��ԑJ��
// ===============================================================
void EnemyGiant::ChangeState(STATE state)
{
    state_ = state;
    CharactorBase::ChangeState(static_cast<int>(state_));
}

void EnemyGiant::ChangeStateNone(void)
{
    stateUpdate_ = std::bind(&EnemyGiant::UpdateNone, this);
}

void EnemyGiant::ChangeStateIdle(void)
{
    stateUpdate_ = std::bind(&EnemyGiant::UpdateIdle, this);

    // �ҋ@���Ԃ͗���������AI�����o��
    float t = static_cast<float>(GetRand(1000)) / 1000.0f;
    idleTimer_ = IDLE_TIME_MIN + (IDLE_TIME_MAX - IDLE_TIME_MIN) * t;

    movePow_ = AsoUtility::VECTOR_ZERO;
    animCtrl_->Play(static_cast<int>(ANIM_TYPE::IDLE), true);
    ResetSteering();
}

void EnemyGiant::ChangeStateWander(void)
{
    stateUpdate_ = std::bind(&EnemyGiant::UpdateWander, this);

    // ���݂̖ڕW�Ɍ�����
    SetMoveDirToTarget(wanderTarget_);

    moveSpeed_ = SPEED_WANDER;
    animCtrl_->Play(static_cast<int>(ANIM_TYPE::WALK), true);
    ResetSteering();
}

void EnemyGiant::ChangeStateChase(void)
{
    stateUpdate_ = std::bind(&EnemyGiant::UpdateChase, this);
    moveSpeed_ = SPEED_CHASE;
    animCtrl_->Play(static_cast<int>(ANIM_TYPE::RUN), true);
    ResetSteering();
}

void EnemyGiant::ChangeStateAttack(void)
{
    stateUpdate_ = std::bind(&EnemyGiant::UpdateAttack, this);
    movePow_ = AsoUtility::VECTOR_ZERO;
    attackHit_ = false;

    SetMoveDirToTarget(player_.GetTransform().pos);

    if (animCtrl_->GetPlayType() == static_cast<int>(ANIM_TYPE::ATTACK))
    {
        animCtrl_->Replay();
    }
    else
    {
        animCtrl_->Play(static_cast<int>(ANIM_TYPE::ATTACK), false);
    }
}

void EnemyGiant::ChangeStateEnd(void)
{
    stateUpdate_ = std::bind(&EnemyGiant::UpdateEnd, this);
}

// ===============================================================
// �e�X�e�[�g�X�V
// ===============================================================
void EnemyGiant::UpdateNone(void) {}
void EnemyGiant::UpdateEnd(void) {}

void EnemyGiant::UpdateIdle(void)
{
    movePow_ = AsoUtility::VECTOR_ZERO;

    // �ҋ@���ł����E�Ƀv���C���[����������ǐ�
    if (IsPlayerInSight())
    {
        ChangeState(STATE::CHASE);
        return;
    }

    idleTimer_ -= scnMng_.GetDeltaTime();
    if (idleTimer_ <= 0.0f)
    {
        PickNextWanderTarget();
        ChangeState(STATE::WANDER);
    }
}

void EnemyGiant::UpdateWander(void)
{
    // ���m���ŗD��
    if (IsPlayerInSight())
    {
        ChangeState(STATE::CHASE);
        return;
    }

    // ���B����
    VECTOR delta = VSub(wanderTarget_, transform_.pos);
    delta.y = 0.0f;
    float distXZ = VSize(delta);

    if (distXZ <= DIST_ARRIVE)
    {
        ChangeState(STATE::IDLE);
        return;
    }

    // �ǂœ����Ȃ��Ȃ�����ʂ̃����_���ڕW�֐ؑ�
    if (IsStuck())
    {
        PickNextWanderTarget();
        ChangeState(STATE::WANDER);
        return;
    }

    // �ڕW���� �� �ǃX���C�h �� �p���x����
    SetMoveDirToTarget(wanderTarget_);
    ApplyWallSlide();
    LimitTurnRate();
    movePow_ = VScale(moveDir_, moveSpeed_);
}

void EnemyGiant::UpdateChase(void)
{
    float dist = DistToPlayer();

    // ���������F���݈ʒu��V�����p�j���S�ɂ��� WANDER ��
    if (dist > DIST_LOSE_CHASE)
    {
        SetWanderCenter(transform_.pos);
        PickNextWanderTarget();
        ChangeState(STATE::WANDER);
        return;
    }

    if (dist <= DIST_ATTACK)
    {
        ChangeState(STATE::ATTACK);
        return;
    }

    VECTOR dir = ComputeChaseDir();
    moveDir_ = dir;
    faceDir_ = dir;

    ApplyWallSlide();
    LimitTurnRate();

    movePow_ = VScale(moveDir_, moveSpeed_);
}

void EnemyGiant::UpdateAttack(void)
{
    const auto& anim = animCtrl_->GetPlayAnim();
    float progress = (anim.totalTime > 0.0f) ? (anim.step / anim.totalTime) : 0.0f;

    bool hitboxActive =
        !attackHit_ &&
        progress >= ATTACK_HIT_START &&
        progress <= ATTACK_HIT_END;

    if (hitboxActive)
    {
        VECTOR spherePos = GetAttackSpherePos();

        for (const auto& hitCol : hitColliders_)
        {
            if (hitCol->GetTag() != ColliderBase::TAG::PLAYER) continue;

            const ColliderCapsule* playerCapsule =
                dynamic_cast<const ColliderCapsule*>(hitCol);
            if (playerCapsule == nullptr) continue;

            VECTOR capTop = playerCapsule->GetPosTop();
            VECTOR capDown = playerCapsule->GetPosDown();
            float  capR = playerCapsule->GetRadius();

            if (AsoUtility::IsHitSphereCapsule(
                spherePos, ATTACK_SPHERE_RADIUS,
                capTop, capDown, capR))
            {
                player_.OnDamagedByEnemy(ATTACK_DAMAGE);
                SoundManager::GetInstance().PlayDamaged();

                attackHit_ = true;
                break;
            }
        }
    }

    if (animCtrl_->IsEnd())
    {
        float dist = DistToPlayer();
        if (dist > DIST_LOSE_CHASE)
        {
            // �U���I���Ō������Ă��ꍇ������������
            SetWanderCenter(transform_.pos);
            PickNextWanderTarget();
            ChangeState(STATE::WANDER);
        }
        else if (dist <= DIST_ATTACK) ChangeState(STATE::ATTACK);
        else                          ChangeState(STATE::CHASE);
    }
}

// ===============================================================
// �w���p�[�F�p�j
// ===============================================================

// wanderCenter_ ���ӂ̓��B�\�ȃ����_���_��I�ԁB
//
// ���w�F���S C ����̋ɍ��W�� (r, ��) �������_���Ɏ��A
//   x = C.x + r cos��,  z = C.z + r sin��
// �Ō��_�𓾂�B���B�\���͎��@�����̃��C�L���X�g�Ŕ���B
void EnemyGiant::PickNextWanderTarget(void)
{
    VECTOR chosen = wanderCenter_; // �t�H�[���o�b�N�F�ǂ���_���Ȃ璆�S���̂���

    for (int i = 0; i < WANDER_MAX_TRIES; ++i)
    {
        // �p�x [0, 2��)
        float theta = static_cast<float>(GetRand(1000)) / 1000.0f
            * (2.0f * DX_PI_F);

        // ���a [WANDER_MIN_DIST, WANDER_RADIUS]
        //   �� �ʐςň�l�ɂ������Ȃ� sqrt(rand) ���|���邪�A
        //     �����ڂ̕��z�͋ϓ��̕����u�p�j���Ă銴�v���o��̂Ő��`�ō̗p
        float rRand = static_cast<float>(GetRand(1000)) / 1000.0f;
        float r = WANDER_MIN_DIST
            + (WANDER_RADIUS - WANDER_MIN_DIST) * rRand;

        VECTOR cand = wanderCenter_;
        cand.x += r * cosf(theta);
        cand.z += r * sinf(theta);

        // ���@������܂ł����ʂ���Ȃ�̗p
        VECTOR from = transform_.pos; from.y += EYE_HEIGHT;
        VECTOR to = cand;             to.y += EYE_HEIGHT;
        if (IsPathClear(from, to))
        {
            chosen = cand;
            break;
        }

        // ���ʂ��Ȃ��Ă��Ō�̎��s���ʂ͊o���Ă���
        // �i�S�ł������ɂ��߂ĉ����ڕW�������������ǂ��j
        chosen = cand;
    }

    wanderTarget_ = chosen;
}

// ���C�L���X�g��2�_�Ԃ��Օ����Ȃ��Œʂ�邩����
bool EnemyGiant::IsPathClear(const VECTOR& from, const VECTOR& to) const
{
    // IsOccludedByColliders �� const �ł͂Ȃ��̂� const_cast �ŉ��
    // �iEnemyBase ���̐݌v�Ɏ�����Ȃ����߁j
    return !const_cast<EnemyGiant*>(this)->IsOccludedByColliders(from, to);
}

void EnemyGiant::SetWanderCenter(const VECTOR& center)
{
    wanderCenter_ = center;
    // �ɒ[�ɍ����ʒu�ɐݒ肳���̂�����邽�� Y �͎��@�̑�����ɂ��Ă���
    wanderCenter_.y = defaultPos_.y;
}

// ===============================================================
// �w���p�[�F�ړ��ƕ���
// ===============================================================
void EnemyGiant::SetMoveDirToTarget(const VECTOR& target)
{
    VECTOR dir = VSub(target, transform_.pos);
    dir.y = 0.0f;
    if (VSize(dir) < 0.01f) return;

    moveDir_ = VNorm(dir);
    faceDir_ = moveDir_;
}

float EnemyGiant::DistToPlayer(void) const
{
    return VSize(VSub(player_.GetTransform().pos, transform_.pos));
}

float EnemyGiant::DistToPlayerXZ(void) const
{
    VECTOR d = VSub(player_.GetTransform().pos, transform_.pos);
    d.y = 0.0f;
    return VSize(d);
}

bool EnemyGiant::IsPlayerInSight(void)
{
    VECTOR myPos = transform_.pos;
    VECTOR plPos = player_.GetTransform().pos;

    VECTOR toPl = VSub(plPos, myPos);
    toPl.y = 0.0f;
    float dist = VSize(toPl);

    if (dist > VIEW_RANGE) return false;
    if (dist < 0.0001f)    return true;

    VECTOR toPlDir = VScale(toPl, 1.0f / dist);

    VECTOR fwd = faceDir_;
    fwd.y = 0.0f;
    if (VSize(fwd) < 0.0001f) return false;
    fwd = VNorm(fwd);

    float cosAngle = VDot(fwd, toPlDir);
    float cosHalfFov = cosf(VIEW_HALF_FOV_RAD);
    if (cosAngle < cosHalfFov) return false;

    VECTOR eye = myPos; eye.y += EYE_HEIGHT;
    VECTOR chest = plPos; chest.y += EYE_HEIGHT;
    if (IsOccludedByColliders(eye, chest)) return false;

    return true;
}

// ---------------------------------------------------------------
// �ǐՕ����̌���i���C�L���X�g�{�q�X�e���V�X�j
// ---------------------------------------------------------------
VECTOR EnemyGiant::ComputeChaseDir(void)
{
    VECTOR myPos = transform_.pos;
    VECTOR plPos = player_.GetTransform().pos;

    VECTOR base = VSub(plPos, myPos);
    base.y = 0.0f;
    float baseLen = VSize(base);
    if (baseLen < 0.001f) return faceDir_;
    base = VScale(base, 1.0f / baseLen);

    VECTOR probeFrom = myPos; probeFrom.y += EYE_HEIGHT;

    auto probe = [&](const VECTOR& dir) -> bool {
        VECTOR to = VAdd(probeFrom, VScale(dir, AVOID_PROBE_DIST));
        return IsOccludedByColliders(probeFrom, to);
        };

    Quaternion rotL = Quaternion::AngleAxis(+AVOID_ANGLE_RAD, AsoUtility::AXIS_Y);
    Quaternion rotR = Quaternion::AngleAxis(-AVOID_ANGLE_RAD, AsoUtility::AXIS_Y);
    VECTOR dirL = rotL.PosAxis(base);
    VECTOR dirR = rotR.PosAxis(base);

    bool blockedFwd = probe(base);

    // �q�X�e���V�X
    if (avoidCommitTimer_ > 0.0f)
    {
        avoidCommitTimer_ -= scnMng_.GetDeltaTime();

        if (lastAvoidChoice_ == 0 && !blockedFwd) return base;
        if (lastAvoidChoice_ == -1 && !probe(dirL)) return dirL;
        if (lastAvoidChoice_ == +1 && !probe(dirR)) return dirR;
    }

    auto commit = [&](int choice, const VECTOR& dir) -> VECTOR {
        lastAvoidChoice_ = choice;
        avoidCommitTimer_ = AVOID_COMMIT_SEC;
        return dir;
        };

    if (!blockedFwd) return commit(0, base);

    bool blockedL = probe(dirL);
    bool blockedR = probe(dirR);

    if (!blockedL && !blockedR)
    {
        VECTOR endL = VAdd(myPos, VScale(dirL, AVOID_PROBE_DIST));
        VECTOR endR = VAdd(myPos, VScale(dirR, AVOID_PROBE_DIST));
        float dL = VSize(VSub(plPos, endL));
        float dR = VSize(VSub(plPos, endR));
        return (dL <= dR) ? commit(-1, dirL) : commit(+1, dirR);
    }
    if (!blockedL) return commit(-1, dirL);
    if (!blockedR) return commit(+1, dirR);

    Quaternion rotWL = Quaternion::AngleAxis(+AVOID_ANGLE_WIDE_RAD, AsoUtility::AXIS_Y);
    Quaternion rotWR = Quaternion::AngleAxis(-AVOID_ANGLE_WIDE_RAD, AsoUtility::AXIS_Y);
    VECTOR dirWL = rotWL.PosAxis(base);
    VECTOR dirWR = rotWR.PosAxis(base);

    if (!probe(dirWL)) return commit(-1, dirWL);
    if (!probe(dirWR)) return commit(+1, dirWR);

    return commit(0, base);
}

void EnemyGiant::PushBackFromPlayer(void)
{
    int capsuleType = static_cast<int>(COLLIDER_TYPE::CAPSULE);
    if (ownColliders_.count(capsuleType) == 0) return;

    ColliderCapsule* myCapsule = dynamic_cast<ColliderCapsule*>(ownColliders_.at(capsuleType));
    if (myCapsule == nullptr) return;

    for (const auto& hitCol : hitColliders_)
    {
        if (hitCol->GetTag() != ColliderBase::TAG::PLAYER) continue;

        const ColliderCapsule* playerCapsule = dynamic_cast<const ColliderCapsule*>(hitCol);
        if (playerCapsule == nullptr) continue;

        VECTOR myC = myCapsule->GetCenter();
        VECTOR plC = playerCapsule->GetCenter();

        float dx = myC.x - plC.x;
        float dz = myC.z - plC.z;
        float distSq = dx * dx + dz * dz;

        float minDist = myCapsule->GetRadius() + playerCapsule->GetRadius();
        if (distSq >= minDist * minDist) return;

        float dist = sqrtf(distSq);
        if (dist < 0.0001f) { dx = 1.0f; dz = 0.0f; dist = 1.0f; }

        float overlap = minDist - dist;
        float k = overlap * 0.5f / dist;

        transform_.pos.x += dx * k;
        transform_.pos.z += dz * k;
        transform_.Update();
        return;
    }
}

VECTOR EnemyGiant::GetAttackSpherePos(void) const
{
    VECTOR framePos = MV1GetFramePosition(transform_.modelId, attackHandFrame_);
    VECTOR worldOffset = transform_.quaRot.PosAxis(ATTACK_SPHERE_OFFSET_LOCAL);
    return VAdd(framePos, worldOffset);
}

// ===============================================================
// �X�e�A�����O�t�B���^
// ===============================================================
void EnemyGiant::UpdateWallNormal(void)
{
    VECTOR expected = VAdd(prevPos_, movePow_);

    float pdx = transform_.pos.x - expected.x;
    float pdz = transform_.pos.z - expected.z;
    float pushLen = sqrtf(pdx * pdx + pdz * pdz);

    if (pushLen < WALL_PUSH_EPSILON)
    {
        wallNormalXZ_ = AsoUtility::VECTOR_ZERO;
        return;
    }

    float inv = 1.0f / pushLen;
    wallNormalXZ_.x = pdx * inv;
    wallNormalXZ_.y = 0.0f;
    wallNormalXZ_.z = pdz * inv;
}

// v_slide = v - (v�En) n  �c �x�N�g���ˉe�ŕǖ@������������
void EnemyGiant::ApplyWallSlide(void)
{
    if (VSize(wallNormalXZ_) < 0.0001f) return;

    float vn = VDot(moveDir_, wallNormalXZ_);
    if (vn >= 0.0f) return;

    moveDir_ = VSub(moveDir_, VScale(wallNormalXZ_, vn));

    float len = VSize(moveDir_);
    if (len > 0.0001f)
    {
        moveDir_ = VScale(moveDir_, 1.0f / len);
    }
    else
    {
        // �ǖ@����90�x��]�����ڐ����̗p
        moveDir_.x = -wallNormalXZ_.z;
        moveDir_.y = 0.0f;
        moveDir_.z = wallNormalXZ_.x;
    }

    faceDir_ = moveDir_;
}

// 1�t���[��������̉�]�ʂ�����Ő����i�p���x���[�p�X�j
void EnemyGiant::LimitTurnRate(void)
{
    if (VSize(prevMoveDir_) < 0.0001f || VSize(moveDir_) < 0.0001f)
    {
        prevMoveDir_ = moveDir_;
        return;
    }

    VECTOR a = prevMoveDir_; a.y = 0.0f;
    VECTOR b = moveDir_;     b.y = 0.0f;
    float la = VSize(a);
    float lb = VSize(b);
    if (la < 0.0001f || lb < 0.0001f)
    {
        prevMoveDir_ = moveDir_;
        return;
    }
    a = VScale(a, 1.0f / la);
    b = VScale(b, 1.0f / lb);

    float cosA = VDot(a, b);
    if (cosA > 1.0f) cosA = 1.0f;
    if (cosA < -1.0f) cosA = -1.0f;
    float angle = acosf(cosA);

    float maxAngle = MAX_TURN_RAD_PER_SEC * scnMng_.GetDeltaTime();

    if (angle <= maxAngle)
    {
        prevMoveDir_ = moveDir_;
        faceDir_ = moveDir_;
        return;
    }

    VECTOR cross = VCross(a, b);
    float sign = (cross.y >= 0.0f) ? +1.0f : -1.0f;

    Quaternion rot = Quaternion::AngleAxis(sign * maxAngle, AsoUtility::AXIS_Y);
    moveDir_ = rot.PosAxis(a);
    faceDir_ = moveDir_;
    prevMoveDir_ = moveDir_;
}

// ===============================================================
// �X�^�b�N���m
// ===============================================================
bool EnemyGiant::IsStuck(void)
{
    float dx = transform_.pos.x - stuckLastPos_.x;
    float dz = transform_.pos.z - stuckLastPos_.z;
    float movedSq = dx * dx + dz * dz;

    if (movedSq < STUCK_MOVE_MIN * STUCK_MOVE_MIN)
    {
        stuckTimer_ += scnMng_.GetDeltaTime();
    }
    else
    {
        stuckTimer_ = 0.0f;
    }
    stuckLastPos_ = transform_.pos;

    return stuckTimer_ >= STUCK_TIMEOUT_SEC;
}

void EnemyGiant::ResetSteering(void)
{
    stuckTimer_ = 0.0f;
    stuckLastPos_ = transform_.pos;
    lastAvoidChoice_ = 0;
    avoidCommitTimer_ = 0.0f;
    prevMoveDir_ = moveDir_;
}

#ifdef _DEBUG
void EnemyGiant::DrawDebugAI(void)
{
    VECTOR pos = transform_.pos;
    pos.y += EYE_HEIGHT;

    VECTOR fwd = faceDir_;
    fwd.y = 0.0f;
    if (VSize(fwd) < 0.0001f) fwd = AsoUtility::DIR_F;
    fwd = VNorm(fwd);

    unsigned int color = IsPlayerInSight() ? GetColor(255, 40, 40) : GetColor(40, 255, 40);

    Quaternion rotL = Quaternion::AngleAxis(+VIEW_HALF_FOV_RAD, AsoUtility::AXIS_Y);
    Quaternion rotR = Quaternion::AngleAxis(-VIEW_HALF_FOV_RAD, AsoUtility::AXIS_Y);
    VECTOR dirL = rotL.PosAxis(fwd);
    VECTOR dirR = rotR.PosAxis(fwd);

    VECTOR endF = VAdd(pos, VScale(fwd, VIEW_RANGE));
    VECTOR endL = VAdd(pos, VScale(dirL, VIEW_RANGE));
    VECTOR endR = VAdd(pos, VScale(dirR, VIEW_RANGE));

    DrawLine3D(pos, endF, color);
    DrawLine3D(pos, endL, color);
    DrawLine3D(pos, endR, color);

    const int SEG = 24;
    VECTOR prev = endL;
    for (int i = 1; i <= SEG; ++i)
    {
        float t = static_cast<float>(i) / SEG;
        float ang = -VIEW_HALF_FOV_RAD + 2.0f * VIEW_HALF_FOV_RAD * t;
        Quaternion rot = Quaternion::AngleAxis(ang, AsoUtility::AXIS_Y);
        VECTOR d = rot.PosAxis(fwd);
        VECTOR e = VAdd(pos, VScale(d, VIEW_RANGE));
        DrawLine3D(prev, e, color);
        prev = e;
    }

    // �p�j�͈͂̉����i���F�̉~�j
    {
        unsigned int rangeCol = GetColor(80, 200, 255);
        VECTOR c = wanderCenter_; c.y += 5.0f;
        const int RSEG = 32;
        VECTOR prevP;
        for (int i = 0; i <= RSEG; ++i)
        {
            float a = (float)i / RSEG * (2.0f * DX_PI_F);
            VECTOR p = c;
            p.x += WANDER_RADIUS * cosf(a);
            p.z += WANDER_RADIUS * sinf(a);
            if (i > 0) DrawLine3D(prevP, p, rangeCol);
            prevP = p;
        }
        // ���S�}�[�J�[
        DrawSphere3D(c, 30.0f, 12, rangeCol, rangeCol, false);
    }

    // ���݂̜p�j�ڕW�i���F�j
    {
        VECTOR t = wanderTarget_; t.y += 5.0f;
        unsigned int col = GetColor(255, 220, 40);
        DrawSphere3D(t, 50.0f, 16, col, col, false);
        // ���@���ڕW�̐�
        VECTOR from = transform_.pos; from.y += EYE_HEIGHT;
        VECTOR to = wanderTarget_;    to.y += EYE_HEIGHT;
        DrawLine3D(from, to, col);
    }

    // �ǖ@���i�I�����W�j
    if (VSize(wallNormalXZ_) > 0.0001f)
    {
        VECTOR from = transform_.pos; from.y += EYE_HEIGHT;
        VECTOR to = VAdd(from, VScale(wallNormalXZ_, 150.0f));
        DrawLine3D(from, to, GetColor(255, 128, 0));
    }
}
#endif