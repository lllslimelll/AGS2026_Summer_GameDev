#include "../../../../Utility/AsoUtility.h"
#include "EnemyBase.h"

EnemyBase::EnemyBase(const EnemyBase::EnemyData& data, Player* player)
	:
	CharactorBase(),
	player_(player),
	type_(data.type),
	hp_(data.hp),
	defaultPos_(data.defaultPos),
	movableRange_(data.movableRange)
{
	// �������W�̐ݒ�
	transform_.pos = data.defaultPos;
}

EnemyBase::~EnemyBase(void)
{
}

void EnemyBase::Draw(void)
{
	CharactorBase::Draw();

#ifdef _DEBUG

	// �ړ��\�͈͂̃f�o�b�O�͈�
	//DrawSphere3D(defaultPos_, movableRange_, 16, 0x000099, 0x000099, false);

#endif // _DEBUG
}

bool EnemyBase::InMovableRange(void) const
{
	bool ret = false;

	// �����ʒu����̋���
	float dis = static_cast<float>(
		AsoUtility::SqrMagnitude(defaultPos_, transform_.pos));
		
	// �w�苗������
	if (dis < movableRange_ * movableRange_)
	{
		return true;
	}

	return ret;
}
