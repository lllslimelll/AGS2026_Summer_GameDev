#include "../../Manager/ResourceManager.h"
#include "../Common/Transform.h"
#include "../../Utility/AsoUtility.h"
#include "../Collider/ColliderModel.h"
#include "Stage.h"

//Stage::Stage(void)
//	:
//	ActorBase()
//{
//}

Stage::~Stage(void)
{
}

void Stage::Update(void)
{
	//// Y����]
	//Quaternion rot = Quaternion::AngleAxis(
	//	AsoUtility::Deg2RadF(0.1f), AsoUtility::AXIS_Y);
	//transform_.quaRot = transform_.quaRot.Mult(rot);
	transform_.Update();
}

void Stage::Draw(void)
{
	ActorBase::Draw();

	VECTOR pos = VAdd(GetRoketPos(), { 120,-95, 40 });
	//DrawSphere3D(pos, 100, 16, 0xffffff, 0xffffff, false);

	MV1DrawModel(model_);

	DrawUI();
}

void Stage::DrawUI(void)
{
	int prevSize = GetFontSize();
	SetFontSize(55);

	// �������J���}��؂蕶����ɕϊ����郉���_
	auto withComma = [](int value, char* out)
		{
			char tmp[32];
			sprintf_s(tmp, 32, "%d", value);
			int len = (int)strlen(tmp);
			int outIdx = 0;
			int firstLen = len % 3;
			if (firstLen == 0) firstLen = 3;
			for (int i = 0; i < firstLen; i++) out[outIdx++] = tmp[i];
			for (int i = firstLen; i < len; i += 3)
			{
				out[outIdx++] = ',';
				out[outIdx++] = tmp[i];
				out[outIdx++] = tmp[i + 1];
				out[outIdx++] = tmp[i + 2];
			}
			out[outIdx] = '\0';
		};

	char totalStr[32];
	char quotaStr[32];
	withComma(totalDelivered_, totalStr);
	withComma(QUOTA, quotaStr);

	char buf[64];
	sprintf_s(buf, "$%s / $%s", totalStr, quotaStr);
	int textW = GetDrawStringWidth(buf, (int)strlen(buf));

	constexpr int SCREEN_W = 1920;
	constexpr int MARGIN = 50;
	int x = SCREEN_W - textW - MARGIN;
	int y = MARGIN;

	unsigned int color = IsQuotaCleared() ? 0x00ff00 : 0xffffff;
	DrawFormatString(x, y, color, "%s", buf);

	SetFontSize(prevSize);
}

void Stage::InitLoad(void)
{
	// ���f���ǂݍ���
	transform_.SetModel(resMng_.Load(
		ResourceManager::SRC::MAIN_STAGE).handleId_);

	model_ = resMng_.Load(ResourceManager::SRC::ROKET).handleId_;
}

void Stage::InitTransform(void)
{
	// �傫��
	transform_.scl = { 2.0f, 2.0f, 2.0f };
	// ���W
	transform_.pos = { 0.0f, 0.0f, 0.0f };

	// ���W
	roketPos_ = { 1300, -860, 430 };

	transform_.Update();

	MV1SetRotationXYZ(model_, VGet(AsoUtility::Deg2RadF(15.0f), AsoUtility::Deg2RadF(0), AsoUtility::Deg2RadF(-130.0f)));
	MV1SetPosition(model_, roketPos_);
}

void Stage::InitCollider(void)
{
	// DxLib���̏Փˏ��Z�b�g�A�b�v
	MV1SetupCollInfo(transform_.modelId);

	// ���f���̃R���C�_
	ColliderModel* colModel =
		new ColliderModel(ColliderBase::TAG::STAGE, &transform_);

	// ���O�t���[���ݒ�
	for (const std::string& name : EXCLUDE_FRAME_NAMES)
	{
		colModel->AddExcludeFrameIds(name);
	}

	// �Ώۃt���[���ݒ�
	for (const std::string& name : TARGET_FRAME_NAMES)
	{ 
		colModel->AddTargetFrameIds(name);
	}

	ownColliders_.emplace(static_cast<int>(COLLIDER_TYPE::MODEL), colModel);
}

void Stage::InitAnimation(void)
{
}

void Stage::InitPost(void)
{
	transform_.Update();
}

const VECTOR& Stage::GetRoketPos() const
{
	return roketPos_;
}

void Stage::AddDelivery(int value)
{
	totalDelivered_ += value;
}

int Stage::GetTotalDelivered(void)
{
	return totalDelivered_;
}

bool Stage::IsQuotaCleared(void) const
{
	return totalDelivered_ >= QUOTA;
}
