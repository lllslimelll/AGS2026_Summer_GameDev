#include "../../Manager/ResourceManager.h"
#include "../Common/Transform.h"
#include "../../Utility/AsoUtility.h"
#include "../Collider/ColliderModel.h"
#include "Stage.h"

//Stage::Stage(void)
//	:
//	ActorBase()
//{
//}

Stage::~Stage(void)
{
}

void Stage::Update(void)
{
	//// Y����]
	//Quaternion rot = Quaternion::AngleAxis(
	//	AsoUtility::Deg2RadF(0.1f), AsoUtility::AXIS_Y);
	//transform_.quaRot = transform_.quaRot.Mult(rot);
	transform_.Update();
}

//void Stage::Draw(void)
//{
//	ActorBase::Draw();
//
//	DrawSphere3D(roketPos_, 80, 16, 0xffffff, 0xffffff, false);
//}

void Stage::InitLoad(void)
{
	// ���f���ǂݍ���
	transform_.SetModel(resMng_.Load(			// 1�� = Load()  ���� = Depulicate()
		ResourceManager::SRC::MAIN_STAGE).handleId_);
}

void Stage::InitTransform(void)
{
	// �傫��
	transform_.scl = AsoUtility::VECTOR_ONE;
	// ���W
	transform_.pos = { 0.0f, 0.0f, 0.0f };

	// ���W
	roketPos_ = VAdd(AsoUtility::VECTOR_ZERO, VScale(AsoUtility::DIR_U, 2600.0f));
}

void Stage::InitCollider(void)
{
	// DxLib���̏Փˏ��Z�b�g�A�b�v
	MV1SetupCollInfo(transform_.modelId);

	// ���f���̃R���C�_
	ColliderModel* colModel =
		new ColliderModel(ColliderBase::TAG::STAGE, &transform_);

	// ���O�t���[���ݒ�
	for (const std::string& name : EXCLUDE_FRAME_NAMES)
	{
		colModel->AddExcludeFrameIds(name);
	}

	// �Ώۃt���[���ݒ�
	for (const std::string& name : TARGET_FRAME_NAMES)
	{ 
		colModel->AddTargetFrameIds(name);
	}

	ownColliders_.emplace(static_cast<int>(COLLIDER_TYPE::MODEL), colModel);
}

void Stage::InitAnimation(void)
{
}

void Stage::InitPost(void)
{
	transform_.Update();
}
