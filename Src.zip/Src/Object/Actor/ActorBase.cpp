#include "../../Manager/ResourceManager.h"
#include "../../Manager/InputManager.h"
#include "../../Scene/SceneManager.h"
#include "../Collider/ColliderBase.h"
#include "../../Camera/Camera.h" 
#include "ActorBase.h"

ActorBase::ActorBase(void)
	: 
	resMng_(ResourceManager::GetInstance()),
	scnMng_(SceneManager::GetInstance()),
	transform_()
{
}

ActorBase::~ActorBase(void)
{
}

void ActorBase::Init(void)
{

	// ���\�[�X���[�h
	InitLoad();

	// Transform������
	InitTransform();

	// �Փ˔���̏�����
	InitCollider();

	// �A�j���[�V�����̏�����
	InitAnimation();

	// ��������̌ʏ���
	InitPost();

}

void ActorBase::Draw(void)
{
	if (renderer_)
	{
		renderer_->Draw();
	}

	//MV1DrawModel(transform_.modelId);

#ifdef _DEBUG

	// ���L���Ă���R���C�_�̕`��
	for (const auto& own : ownColliders_)
	{
		own.second->Draw();
	}

#endif // _DEBUG
}

void ActorBase::Release(void)
{
	transform_.Release();

	// ���g�̃R���C�_���
	for (auto& own : ownColliders_)
	{
		delete own.second;
	}
	ownColliders_.clear();
}

const Transform& ActorBase::GetTransform(void) const
{
	return transform_;
}


// ����̎��g�̏Փˏ��
const ColliderBase* ActorBase::GetOwnCollider(int key) const
{
	if (ownColliders_.count(key) == 0)
	{
		return nullptr;
	}
	return ownColliders_.at(key);
}

// �ՓˑΏۂƂȂ�R���C�_��o�^
void ActorBase::AddHitCollider(const ColliderBase* hitCollider)
{
	for (const auto& c : hitColliders_)
	{
		if (c == hitCollider)
		{
			return;
		}
	}

	hitColliders_.emplace_back(hitCollider);
}

// �ՓˑΏۂƂȂ�R���C�_���N���A
void ActorBase::ClearHitCollider(void)
{
	hitColliders_.clear();
}

bool ActorBase::IsOccludedByColliders(const VECTOR& from, const VECTOR& to) const
{
	for (const auto& c : hitColliders_)
	{
		if (!c->IsOccluder()) continue;
		if (c->IsOccluded(from, to)) return true;
	}
	return false;
}

void ActorBase::InitCurvatureStageShader(void)
{
	material_ = std::make_unique<ModelMaterial>(
		"StageVS.vso", 1,
		"StagePS.pso", 0);

	Camera& cam = SceneManager::GetInstance().GetCamera();
	VECTOR camPos = cam.GetPos();
	material_->AddConstBufVS({ camPos.x, camPos.y, camPos.z, 0.0f });

	renderer_ = std::make_unique<ModelRenderer>(*material_, transform_.modelId);
}

void ActorBase::InitCurvatureItemShader(void)
{
	material_ = std::make_unique<ModelMaterial>(
		"StageVS.vso", 1,
		"ItemPS.pso", 0);

	Camera& cam = SceneManager::GetInstance().GetCamera();
	VECTOR camPos = cam.GetPos();
	material_->AddConstBufVS({ camPos.x, camPos.y, camPos.z, 0.0f });

	renderer_ = std::make_unique<ModelRenderer>(*material_, transform_.modelId);
}

void ActorBase::InitCurvatureShaderSkinned(void)
{
	material_ = std::make_unique<ModelMaterial>(
		"EnemyVS.vso", 1,
		"StagePS.pso", 0);
	Camera& cam = SceneManager::GetInstance().GetCamera();
	VECTOR camPos = cam.GetPos();
	material_->AddConstBufVS({ camPos.x, camPos.y, camPos.z, 0.0f });
	renderer_ = std::make_unique<ModelRenderer>(*material_, transform_.modelId);
}

void ActorBase::UpdateCurvatureShader(void)
{
	if (!material_) return;
	Camera& cam = SceneManager::GetInstance().GetCamera();
	VECTOR camPos = cam.GetPos();
	material_->SetConstBufVS(0, { camPos.x, camPos.y, camPos.z, 0.0f });
}
