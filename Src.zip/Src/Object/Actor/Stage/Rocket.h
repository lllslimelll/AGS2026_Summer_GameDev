#pragma once
#include "../ActorBase.h"

class Rocket : public ActorBase
{
public:

    // �Փ˔�����
    enum class COLLIDER_TYPE
    {
        MODEL = 0,
        MAX,
    };

    ~Rocket(void) override;

    void Update(void) override;
    void Draw(void)   override;

    // �[�i
    void AddDelivery(int value);

    // �݌v�[�i�z
    int GetTotalDelivered(void) const;

    // �m���}�N���A������
    bool IsQuotaCleared(void) const;

    // ���W�擾
    const VECTOR& GetPos(void) const;

protected:

    virtual void InitLoad(void)      override;
    virtual void InitTransform(void) override;
    virtual void InitCollider(void)  override;
    virtual void InitAnimation(void) override;
    virtual void InitPost(void)      override;

private:

    static constexpr int QUOTA = 5000;

    int totalDelivered_ = 0;
};