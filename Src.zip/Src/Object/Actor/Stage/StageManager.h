#pragma once
#include <memory>
#include <DxLib.h>

class Planet;
class Rocket;
class ColliderBase;

class StageManager
{
public:

    StageManager(void);
    ~StageManager(void);

    void Init(void);
    void Update(void);
    void Draw(void);
    void DrawUI(void);
    void Release(void);

    // ���P�b�g�擾
    Rocket& GetRocket(void);

    // �f���擾
    Planet& GetPlanet(void);

    // Transform�擾�i�V���h�E�}�b�v�p�j
    const Transform& GetTransform(void) const;

private:

    std::unique_ptr<Planet> planet_;
    std::unique_ptr<Rocket> rocket_;
};