#include <cmath>
#include <DxLib.h>
#include "../Application.h"
#include "../Utility/AsoUtility.h"
#include "../Object/Common/AnimationController.h"
#include "../Object/Actor/SkyDome.h"
#include "../Manager/InputManager.h"
#include "../Camera/Camera.h"
#include "../Manager/ResourceManager.h"
#include "../Manager/SoundManager.h"
#include "SceneManager.h"
#include "TitleScene.h"

// ���j���[���x���iMENU_ITEM �̏��ɑΉ��j
static const char* MENU_LABELS[] =
{
	"�T�����J�n",
	"�ݒ�",
	"�I��"
};

// �����̓_���iDxLib�ɓ_��API�͖����̂ŒZ���j������ׂ�j
static void DrawDottedLineH(int x1, int x2, int y, unsigned int color,
	int dashLen, int gapLen, int thickness)
{
	for (int x = x1; x < x2; x += dashLen + gapLen)
	{
		const int ex = (x + dashLen < x2) ? x + dashLen : x2;
		DrawBox(x, y, ex, y + thickness, color, TRUE);
	}
}
// �I�� = �ԁA��I�� = ���i�Q�l�摜�����j
static constexpr unsigned int COLOR_SELECT = 0xFF2222;
static constexpr unsigned int COLOR_UNSELECT = 0xFFFFFF;
static constexpr unsigned int COLOR_TITLE = 0xFFFFFF;


static constexpr int LINE_WIDTH = 500;               // �_���̒���
static constexpr int LINE_PAD_Y = 130;                // ���j���[�㉺�Ɠ_���̊Ԋu
static constexpr unsigned int COLOR_LINE = 0xFFFFFF; // �_���F�i�����F�Ƃ͖��֌W�j

TitleScene::TitleScene(void)
	:
	imgPushSpace_(-1),
	SceneBase(),
	skyDome_()
{
}

TitleScene::~TitleScene(void)
{
	skyDome_->Release();
}

void TitleScene::Init(void)
{
	// BGM�Đ�
	SoundManager::GetInstance().PlayBgmTitle();

	// ���̘f��
	spherePlanet_.SetModel(resMng_.Load(			// 1�� = Load()  ���� = Depulicate()
		ResourceManager::SRC::STAGE).handleId_);
	spherePlanet_.scl = { 0.7f, 0.7f, 0.7f };
	spherePlanet_.quaRot = Quaternion::Identity();

	//spherePlanet_.pos = { 900, -600, 300 };
	spherePlanet_.pos = { -250, -620.0f, -7100.0f };
	spherePlanet_.quaRotLocal = Quaternion::Mult(
		spherePlanet_.quaRotLocal,
		Quaternion::AngleAxis(AsoUtility::Deg2RadF(50.0f), AsoUtility::AXIS_Y));
	spherePlanet_.quaRotLocal = Quaternion::Mult(
		spherePlanet_.quaRotLocal,
		Quaternion::AngleAxis(AsoUtility::Deg2RadF(-20.0f), AsoUtility::AXIS_X));
	spherePlanet_.quaRotLocal = Quaternion::Mult(
		spherePlanet_.quaRotLocal,
		Quaternion::AngleAxis(AsoUtility::Deg2RadF(30.0f), AsoUtility::AXIS_Z));
	spherePlanet_.Update();

	// ��_�J����
	SceneManager::GetInstance().GetCamera().ChangeMode(Camera::MODE::FIXED_POINT);

	// �X�J�C�h�[��
	skyDome_ = std::make_unique<SkyDome>(empty_);
	skyDome_->Init();

}

void TitleScene::Update(void)
{
	skyDome_->Update();

	// �f����X���ɖ��t���[��1������]��ǉ�
	/*spherePlanet_.quaRotLocal = Quaternion::Mult(
		spherePlanet_.quaRotLocal,
		Quaternion::AngleAxis(AsoUtility::Deg2RadF(-0.1f), AsoUtility::AXIS_Z));*/

	spherePlanet_.quaRotLocal = Quaternion::Mult(
		spherePlanet_.quaRotLocal,
		Quaternion::AngleAxis(AsoUtility::Deg2RadF(-0.05f), AsoUtility::AXIS_Y));
	//spherePlanet_.quaRotLocal = Quaternion::Mult(
	//	spherePlanet_.quaRotLocal,
	//	Quaternion::AngleAxis(AsoUtility::Deg2RadF(-0.00f), AsoUtility::AXIS_Z));
	// ���f���s����X�V
	spherePlanet_.Update();

	UpdateInput();
}

void TitleScene::UpdateInput(void)
{
	auto const& ins = InputManager::GetInstance();

	int prevIndex = selectIndex_;

	// ���j���[�I��
	if (ins.IsTriggered(InputManager::InputCommand::UI_UP))
	{
		selectIndex_ = (selectIndex_ - 1 + MENU_COUNT) % MENU_COUNT;
	}
	if (ins.IsTriggered(InputManager::InputCommand::UI_DOWN))
	{
		selectIndex_ = (selectIndex_ + 1) % MENU_COUNT;
	}

	// �}�E�X���W�擾
	int mouseX, mouseY;
	GetMousePoint(&mouseX, &mouseY);

	bool mouseMoved = (mouseX != prevMouseX_ || mouseY != prevMouseY_);

	if (mouseMoved)
	{
		int mouseHoverIndex = -1;
		const int halfW = LINE_WIDTH / 2;
		for (int i = 0; i < MENU_COUNT; ++i)
		{
			int itemY = MENU_Y_START + i * MENU_LINE_HEIGHT;
			if (mouseX >= MENU_CENTER_X - halfW && mouseX <= MENU_CENTER_X + halfW &&
				mouseY >= itemY && mouseY <= itemY + MENU_LINE_HEIGHT)
			{
				mouseHoverIndex = i;
				break;
			}
		}
		selectIndex_ = mouseHoverIndex;
	}

	prevMouseX_ = mouseX;
	prevMouseY_ = mouseY;

	// ����
	bool decide = ins.IsTriggered(InputManager::InputCommand::UI_DECIDE);

	if (decide && selectIndex_ != -1)
	{
		SoundManager::GetInstance().PlaySelect();
		switch (static_cast<MENU>(selectIndex_))
		{
		case MENU::GAME_START:
			sceMng_.ChangeScene(SceneManager::SCENE_ID::PROLOGUE);
			SoundManager::GetInstance().StopBGMTitle();
			break;
		case MENU::OPTION:
			SceneManager::GetInstance().PushOverlay(SceneManager::SCENE_ID::OPTION);
			break;
		case MENU::QUIT_GAME:
			PostQuitMessage(0);
			break;
		default:
			break;
		}
	}
}

// �`��
void TitleScene::Draw(void)
{

	// �X�J�C�h�[��
	skyDome_->Draw();
	// �f��
	MV1DrawModel(spherePlanet_.modelId);

	DrawTitle();
	DrawMenu();
}

void TitleScene::DrawTitle(void) const
{
	SetFontSize(TITLE_FONT_SIZE);
	DrawFormatString(TITLE_X, 190, 0xFF8C00, "�f���T��");
}

void TitleScene::DrawMenu(void) const
{
	// --- ���j���[�����ޏ㉺�̓_���i���S��ō��E�Ώ̂Ɂj ---
	const int lastItemY = MENU_Y_START + (MENU_COUNT - 1) * MENU_LINE_HEIGHT;
	const int frameTop = MENU_Y_START - LINE_PAD_Y;
	const int frameBottom = lastItemY + MENU_FONT_SIZE + LINE_PAD_Y;

	DrawDottedLineH(MENU_CENTER_X - LINE_WIDTH / 2, MENU_CENTER_X + LINE_WIDTH / 2,
		frameTop, COLOR_LINE, 2, 3, 1);
	DrawDottedLineH(MENU_CENTER_X - LINE_WIDTH / 2, MENU_CENTER_X + LINE_WIDTH / 2,
		frameBottom, COLOR_LINE, 2, 3, 1);

	SetFontSize(MENU_FONT_SIZE);

	const int triH = MENU_FONT_SIZE;
	const int triW = MENU_FONT_SIZE / 2;
	const int gap = MENU_FONT_SIZE / 3;

	for (int i = 0; i < MENU_COUNT; ++i)
	{
		const bool isSelected = (i == selectIndex_);
		const int  y = MENU_Y_START + i * MENU_LINE_HEIGHT;

		// ���ڂ��Ƃɕ��𑪂�A���S���獶�E�ϓ��ɔz�u����
		const int len = static_cast<int>(std::strlen(MENU_LABELS[i]));
		const int textW = GetDrawStringWidth(MENU_LABELS[i], len);
		const int textX = MENU_CENTER_X - textW / 2;   // ���̍��ڂ̊J�nX

		const unsigned int color = isSelected ? 0xFFFFFF : 0xFF8C00;
		DrawFormatString(textX, y, color, MENU_LABELS[i]);

		if (!isSelected) { continue; }

		const int cy = y + triH / 2;

		// ���F�E�����O�p�i�e�L�X�g���[�̎�O�j
		const int lTip = textX - gap;
		const int lBase = lTip - triW;
		DrawTriangle(lBase, cy - triH / 2, lBase, cy + triH / 2, lTip, cy, 0xFFFFFF, TRUE);

		// �E�F�������O�p�i�e�L�X�g�E�[�̐�j
		const int rTip = textX + textW + gap;
		const int rBase = rTip + triW;
		DrawTriangle(rBase, cy - triH / 2, rBase, cy + triH / 2, rTip, cy, 0xFFFFFF, TRUE);
	}
}
