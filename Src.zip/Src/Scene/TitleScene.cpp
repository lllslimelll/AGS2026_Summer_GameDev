#include <DxLib.h>
#include "../Application.h"
#include "../Utility/AsoUtility.h"
#include "../Object/Common/AnimationController.h"
#include "../Object/Actor/SkyDome.h"
#include "../Manager/InputManager.h"
#include "../Manager/SceneManager.h"
#include "../Manager/Camera.h"
#include "../Manager/ResourceManager.h"
#include "TitleScene.h"

TitleScene::TitleScene(void)
	:
	//imgTitle_(-1),
	imgPushSpace_(-1),
	//bigPlanet_(),
	//spherePlanet_(),
	player_(),
	animController_(),
	SceneBase(),
	skyDome_()
{
}

TitleScene::~TitleScene(void)
{
}

void TitleScene::Init(void)
{

	// PushSpace�摜�ǂݍ���
	imgPushSpace_ = resMng_.Load(ResourceManager::SRC::PUSH_SPACE).handleId_;

	// ��_�J����
	sceMng_.GetCamera()->ChangeMode(Camera::MODE::FIXED_POINT);

	// ���̘f��
	spherePlanet_.SetModel(resMng_.Load(			// 1�� = Load()  ���� = Depulicate()
		ResourceManager::SRC::MAIN_STAGE).handleId_);
	spherePlanet_.scl = { 0.7f, 0.7f, 0.7f };
	spherePlanet_.quaRot = Quaternion::Identity();

	spherePlanet_.pos = { 600, -300, 550 };
	spherePlanet_.Update();

	// �X�J�C�h�[��
	skyDome_ = new SkyDome(empty_);
	skyDome_->Init();
}

void TitleScene::Update(void)
{
	skyDome_->Update();

	// �f����X���ɖ��t���[��1������]��ǉ�
	spherePlanet_.quaRotLocal = Quaternion::Mult(
		spherePlanet_.quaRotLocal,
		Quaternion::AngleAxis(AsoUtility::Deg2RadF(-1.0f), AsoUtility::AXIS_Z));

	// ���f���s����X�V
	spherePlanet_.Update();

	// �V�[���J��
	auto const& ins = InputManager::GetInstance();
	bool decide = ins.IsTrgDown(KEY_INPUT_SPACE)
		|| ins.IsPadBtnTrgDown(InputManager::JOYPAD_NO::PAD1, InputManager::JOYPAD_BTN::LEFT);
	if(decide)
	{
		sceMng_.ChangeScene(SceneManager::SCENE_ID::GAME);
	}
}

void TitleScene::Draw(void)
{
	skyDome_->Draw();

	// �f���`��
	MV1DrawModel(spherePlanet_.modelId);

	//// �^�C�g���摜�`��
	//DrawRotaGraph(
	//	Application::SCREEN_SIZE_X / 2,
	//	Application::SCREEN_SIZE_Y / 2 - 50,
	//	1.0f,
	//	0.0,
	//	imgTitle_,
	//	TRUE
	//);

	if (GetJoypadNum() == 0)
	{
		// PushSpace�`��
		DrawRotaGraph(
			Application::SCREEN_SIZE_X / 2,
			Application::SCREEN_SIZE_Y - 120,
			1.0f,
			0.0,
			imgPushSpace_,
			TRUE
		);
	}
	else
	{
		SetFontSize(50);
		//DrawFormatString(Application::SCREEN_SIZE_X / 2,
			//Application::SCREEN_SIZE_Y / 2 + 400, 0xffffff, "Push A Button");
	}
	SetFontSize(140);
	DrawFormatString(170,
		150, 0xffffff, "�f���T��");
}

void TitleScene::Release(void)
{
	skyDome_->Release();
	delete skyDome_;

	animController_->Release();
	delete animController_;
}
