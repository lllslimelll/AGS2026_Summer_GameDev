#include <cmath>
#include <DxLib.h>
#include "../Application.h"
#include "../Utility/AsoUtility.h"
#include "../Object/Common/AnimationController.h"
#include "../Object/Actor/SkyDome.h"
#include "../Manager/InputManager.h"
#include "../Manager/SceneManager.h"
#include "../Manager/Camera.h"
#include "../Manager/ResourceManager.h"
#include "TitleScene.h"
// ���j���[���x���iMENU_ITEM �̏��ɑΉ��j
static const char* MENU_LABELS[] = {
	"GAME START",
	"TUTORIAL",
	"OPTION",
	"RANKING",
	"QUIT GAME",
};
// �I�� = �ԁA��I�� = ���i�Q�l�摜�����j
static constexpr unsigned int COLOR_SELECT = 0xFF2222;
static constexpr unsigned int COLOR_UNSELECT = 0xFFFFFF;
static constexpr unsigned int COLOR_TITLE = 0xFFFFFF;

TitleScene::TitleScene(void)
	:
	imgPushSpace_(-1),
	player_(),
	SceneBase(),
	skyDome_()
{
}

TitleScene::~TitleScene(void)
{
}

void TitleScene::Init(void)
{
	// PushSpace�摜�ǂݍ���
	imgPushSpace_ = resMng_.Load(ResourceManager::SRC::PUSH_SPACE).handleId_;

	// ��_�J����
	sceMng_.GetCamera()->ChangeMode(Camera::MODE::FIXED_POINT);

	// ���̘f��
	spherePlanet_.SetModel(resMng_.Load(			// 1�� = Load()  ���� = Depulicate()
		ResourceManager::SRC::MAIN_STAGE).handleId_);
	spherePlanet_.scl = { 0.7f, 0.7f, 0.7f };
	spherePlanet_.quaRot = Quaternion::Identity();

	spherePlanet_.pos = { 600, -300, 550 };
	spherePlanet_.Update();

	// �X�J�C�h�[��
	skyDome_ = new SkyDome(empty_);
	skyDome_->Init();

}

void TitleScene::Update(void)
{
	skyDome_->Update();

	// �f����X���ɖ��t���[��1������]��ǉ�
	spherePlanet_.quaRotLocal = Quaternion::Mult(
		spherePlanet_.quaRotLocal,
		Quaternion::AngleAxis(AsoUtility::Deg2RadF(-0.1f), AsoUtility::AXIS_Z));

	// ���f���s����X�V
	spherePlanet_.Update();

	UpdateInput();
}

void TitleScene::UpdateInput(void)
{
	auto const& ins = InputManager::GetInstance();

	// �}�E�X���W�擾
	int mouseX, mouseY;
	GetMousePoint(&mouseX, &mouseY);

	// �}�E�X�����j���[���ڂɏd�Ȃ��Ă�����selectIndex���X�V
	for (int i = 0; i < MENU_COUNT; ++i)
	{
		int itemY = MENU_Y_START + i * MENU_LINE_HEIGHT;
		// �����蔻��̋�`�i�����͓K�X�����j
		if (mouseX >= MENU_X && mouseX <= MENU_X + 300 &&
			mouseY >= itemY && mouseY <= itemY + MENU_LINE_HEIGHT)
		{
			selectIndex_ = i;
		}
	}

	// ���� �ŃJ�[�\���ړ�
	if (ins.IsTrgDown(KEY_INPUT_UP) ||
		ins.IsPadBtnTrgDown(InputManager::JOYPAD_NO::PAD1,
			InputManager::JOYPAD_BTN::TOP))
	{
		selectIndex_ = (selectIndex_ - 1 + MENU_COUNT) % MENU_COUNT;
	}
	if (ins.IsTrgDown(KEY_INPUT_DOWN) ||
		ins.IsPadBtnTrgDown(InputManager::JOYPAD_NO::PAD1,
			InputManager::JOYPAD_BTN::DOWN))
	{
		selectIndex_ = (selectIndex_ + 1) % MENU_COUNT;
	}

	// ����i�}�E�X���N���b�N�ǉ��j
	bool decide = ins.IsTrgDown(KEY_INPUT_RETURN)
		|| ins.IsTrgDown(KEY_INPUT_SPACE)
		|| ins.IsPadBtnTrgDown(InputManager::JOYPAD_NO::PAD1,
			InputManager::JOYPAD_BTN::LEFT)
		|| (GetMouseInput() & MOUSE_INPUT_LEFT);  // ���N���b�N

	if (decide)
	{
		switch (static_cast<MENU>(selectIndex_))
		{
		case MENU::GAME_START:
			sceMng_.ChangeScene(SceneManager::SCENE_ID::GAME);
			break;
		case MENU::QUIT_GAME:
			PostQuitMessage(0);
			break;
		default:
			break;
		}
	}

}

void TitleScene::Draw(void)
{
	skyDome_->Draw();
	MV1DrawModel(spherePlanet_.modelId);

	DrawTitle();
	DrawMenu();
}

void TitleScene::DrawTitle(void) const
{
	SetFontSize(TITLE_FONT_SIZE);
	DrawFormatString(MENU_X, 80, 0xFF8C00, "�f������");
}

void TitleScene::DrawMenu(void) const
{
	SetFontSize(MENU_FONT_SIZE);

	for (int i = 0; i < MENU_COUNT; ++i)
	{
		const bool isSelected = (i == selectIndex_);
		const int y = MENU_Y_START + i * MENU_LINE_HEIGHT;

		if (isSelected)
		{
			DrawFormatString(MENU_X - 40, y, 0xFFFFFF, ">");
			DrawFormatString(MENU_X, y, 0xFFFFFF, MENU_LABELS[i]);
		}
		else
		{
			DrawFormatString(MENU_X, y, 0xFF8C00, MENU_LABELS[i]);
		}
	}
}

void TitleScene::Release(void)
{
	skyDome_->Release();
	delete skyDome_;
}
