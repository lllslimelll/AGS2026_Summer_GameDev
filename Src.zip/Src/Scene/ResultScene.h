#pragma once
#include "SceneBase.h"

class ResultScene :	public SceneBase
{
public:

	// �R���X�g���N�^�E�f�X�g���N�^
	ResultScene();
	~ResultScene() override;

	// ������
	void Init(void) override;

	// �X�V
	void Update(void) override;

	// �`��
	void Draw(void) override;

private:

	int   totalScore_ = 0;
	float revealTimer_ = 0.0f;

	bool playedScore_ = false;
	bool playedStatus_ = false;
	bool playedGrade_ = false;

	static constexpr float TIME_SCORE = 1.0f;
	static constexpr float TIME_STATUS = 2.0f;
	static constexpr float TIME_GRADE = 3.0f;
};

