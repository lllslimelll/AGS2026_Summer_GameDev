#include "SoundManager.h"
#include "InputManager.h"
#include "DxLib.h"

// �O���[�o���̈�ŕϐ���������
SoundManager* SoundManager::instance_ = nullptr;

SoundManager::SoundManager(void)
{
}

//�C���X�^���X�̐���
void SoundManager::CreateInstance(void)
{
	if (instance_ == nullptr)
	{
		instance_ = new SoundManager;
	}

	instance_->Init();
}

SoundManager& SoundManager::GetInstance(void)
{
	return *instance_;
}

void SoundManager::Init(void)
{
	bgmTitleH_ = LoadSoundMem(BGM_TITLE_PATH);
	walkH_ = LoadSoundMem(WALK_PATH);
	pickUpH_ = LoadSoundMem(PICKUP_PATH);
	boostH_ = LoadSoundMem(BOOST_PATH);

	// ���ʒ���
	ChangeVolumeSoundMem(BGM_TITLE_VOLUME, bgmTitleH_);
	ChangeVolumeSoundMem(WALK_VOLUME, walkH_);
	ChangeVolumeSoundMem(PICKUP_VOLUME, pickUpH_);
	ChangeVolumeSoundMem(BOOST_VOLUME, boostH_);

}

void SoundManager::Update(void)
{
}

void SoundManager::Destroy(void)
{
	DeleteSoundMem(bgmTitleH_);
	DeleteSoundMem(walkH_);
	DeleteSoundMem(pickUpH_);
	DeleteSoundMem(boostH_);

	// �C���X�^���X�̃��������
	delete instance_;
}

void SoundManager::PlayBgmTitle()
{
	// �Đ�
	if (CheckSoundMem(bgmTitleH_) == 0)
	{
		PlaySoundMem(bgmTitleH_, DX_PLAYTYPE_LOOP, true);
	}
}

void SoundManager::PlayWalk()
{
	// �Đ�
	if (CheckSoundMem(walkH_) == 0)
	{
		PlaySoundMem(walkH_, DX_PLAYTYPE_LOOP, true);
	}
}

void SoundManager::PlayPickUp()
{
	PlaySoundMem(pickUpH_, DX_PLAYTYPE_BACK, true);
}

void SoundManager::PlayBoost()
{
	// �Đ�
	if (CheckSoundMem(boostH_) == 0)
	{
		PlaySoundMem(boostH_, DX_PLAYTYPE_LOOP, true);
	}
}

void SoundManager::StopBGMTitle()
{
	StopSoundMem(bgmTitleH_);
}

void SoundManager::StopWalk()
{
	StopSoundMem(walkH_);
}

void SoundManager::StopPickUp()
{
	StopSoundMem(pickUpH_);
}

void SoundManager::StopBoost()
{
	StopSoundMem(boostH_);
}
