#include <string>
#include "../Application.h"
#include "../Utility/AsoUtility.h"
#include "InputManager.h"

InputManager* InputManager::instance_ = nullptr;

void InputManager::CreateInstance(void)
{
	if (instance_ == nullptr)
	{
		instance_ = new InputManager();
	}
	instance_->Init();
}

InputManager& InputManager::GetInstance(void)
{
	if (instance_ == nullptr)
	{
		InputManager::CreateInstance();
	}
	return *instance_;
}

void InputManager::Init(void)
{

	// �Q�[���Ŏg�p�������L�[���A
	// ���O�ɂ����œo�^���Ă����Ă�������
	InputManager::GetInstance().Add(KEY_INPUT_SPACE);
	InputManager::GetInstance().Add(KEY_INPUT_E);
	InputManager::GetInstance().Add(KEY_INPUT_Z);

	InputManager::GetInstance().Add(KEY_INPUT_LEFT);
	InputManager::GetInstance().Add(KEY_INPUT_RIGHT);
	InputManager::GetInstance().Add(KEY_INPUT_UP);
	InputManager::GetInstance().Add(KEY_INPUT_DOWN);

	InputManager::GetInstance().Add(KEY_INPUT_W);
	InputManager::GetInstance().Add(KEY_INPUT_A);
	InputManager::GetInstance().Add(KEY_INPUT_S);
	InputManager::GetInstance().Add(KEY_INPUT_D);
	InputManager::GetInstance().Add(KEY_INPUT_F);
	InputManager::GetInstance().Add(KEY_INPUT_C);

	InputManager::GetInstance().Add(KEY_INPUT_LSHIFT);

	InputManager::GetInstance().Add(KEY_INPUT_BACKSLASH);

	GetInstance().Add(KEY_INPUT_1);
	GetInstance().Add(KEY_INPUT_2);
	GetInstance().Add(KEY_INPUT_3);
	GetInstance().Add(KEY_INPUT_4);
	GetInstance().Add(KEY_INPUT_5);

	GetInstance().Add(KEY_INPUT_0);

	GetInstance().Add(KEY_INPUT_ESCAPE);

	InputManager::MouseInfo info;

	// ���N���b�N
	info = InputManager::MouseInfo();
	info.key = MOUSE_INPUT_LEFT;
	info.keyOld = false;
	info.keyNew = false;
	info.keyTrgDown = false;
	info.keyTrgUp = false;
	mouseInfos_.emplace(info.key, info);

	// �E�N���b�N
	info = InputManager::MouseInfo();
	info.key = MOUSE_INPUT_RIGHT;
	info.keyOld = false;
	info.keyNew = false;
	info.keyTrgDown = false;
	info.keyTrgUp = false;
	mouseInfos_.emplace(info.key, info);

	mouseWheelRot_ = 0;

	inputTable_["Up"] = { //{PeripheralType::KEYBOAD, KEY_INPUT_UP},
							//{PeripheralType::KEYBOAD, KEY_INPUT_W},
							{PeripheralType::PAD, PAD_INPUT_UP} };

	inputTable_["Down"] = { //{PeripheralType::KEYBOAD, KEY_INPUT_DOWN},
								//{PeripheralType::KEYBOAD, KEY_INPUT_S},
								{PeripheralType::PAD, PAD_INPUT_DOWN} };

	inputTable_["left"] = { {PeripheralType::KEYBOAD, KEY_INPUT_LEFT},
								{PeripheralType::KEYBOAD, KEY_INPUT_A},
								{PeripheralType::PAD, PAD_INPUT_LEFT} };

	inputTable_["right"] = { {PeripheralType::KEYBOAD, KEY_INPUT_RIGHT},
								{PeripheralType::KEYBOAD, KEY_INPUT_D},
								{PeripheralType::PAD, PAD_INPUT_RIGHT} };

	// DX���C�u������PAD�̃{�^���ԍ���6�{�^���x�[�X�Ȃ̂ł���Ă��܂�
	inputTable_["ok"] = { {PeripheralType::KEYBOAD, KEY_INPUT_RETURN},
								{PeripheralType::MOUSE, MOUSE_INPUT_LEFT},
								{PeripheralType::PAD, PAD_INPUT_DOWN} }; // SELECT�{�^��

	inputTable_["pause"] = { {PeripheralType::KEYBOAD, KEY_INPUT_P},
								{PeripheralType::PAD, PAD_INPUT_R} }; // START�{�^��

	inputTable_["jump"] = { {PeripheralType::KEYBOAD, KEY_INPUT_Z},
								{PeripheralType::PAD, PAD_INPUT_C} }; // X�{�^��

	inputTable_["attack"] = { {PeripheralType::KEYBOAD, KEY_INPUT_X},
								{PeripheralType::PAD, PAD_INPUT_A} }; // A�{�^��

	for (auto& inputInfo : inputTable_)
	{
		currentInputInfo_[inputInfo.first] = false;
		lastInputInfo_[inputInfo.first] = false;
	}
}

void InputManager::Update(void)
{

	// �L�[�{�[�h���m
	for (auto& p : keyInfos_)
	{
		p.second.keyOld = p.second.keyNew;
		p.second.keyNew = CheckHitKey(p.second.key);
		p.second.keyTrgDown = p.second.keyNew && !p.second.keyOld;
		p.second.keyTrgUp = !p.second.keyNew && p.second.keyOld;
	}

	// �}�E�X���m
	mouseInput_ = GetMouseInput();
	GetMousePoint(&mousePos_.x, &mousePos_.y);

	for (auto& p : mouseInfos_)
	{
		p.second.keyOld = p.second.keyNew;
		p.second.keyNew = mouseInput_ == p.second.key;
		p.second.keyTrgDown = p.second.keyNew && !p.second.keyOld;
		p.second.keyTrgUp = !p.second.keyNew && p.second.keyOld;
	}

	// �p�b�h���
	SetJPadInState(JOYPAD_NO::KEY_PAD1);
	SetJPadInState(JOYPAD_NO::PAD1);
	SetJPadInState(JOYPAD_NO::PAD2);
	SetJPadInState(JOYPAD_NO::PAD3);
	SetJPadInState(JOYPAD_NO::PAD4);

	// �}�E�X�z�C�[���̉�]�ʂ��擾
	mouseWheelRot_ = GetMouseWheelRotVol();

	lastInputInfo_ = currentInputInfo_;
	// ���f�[�^�擾
	std::array<char, 256> keyState;
	GetHitKeyStateAll(keyState.data());
	int mouseState = GetMouseInput();
	int padState = GetJoypadInputState(DX_INPUT_PAD1); // 1�R���g���[���[����

	// ���f�[�^����̓t���O�ɔ��f
	for (auto& inputInfo : inputTable_)
	{
		const auto& eventName = inputInfo.first;

		for (auto& inputState : inputInfo.second)
		{
			switch (inputState.type)
			{
			case PeripheralType::KEYBOAD:
				currentInputInfo_[eventName] = keyState[inputState.id];
				break;
			case PeripheralType::MOUSE:
				currentInputInfo_[eventName] = mouseState & inputState.id;
				break;
			case PeripheralType::PAD:
				currentInputInfo_[eventName] = padState & inputState.id;
				break;
			}
			if (currentInputInfo_[eventName])
			{
				break;
			}
		}
	}

}
bool InputManager::IsPressed(const std::string& name) const
{
	if (!currentInputInfo_.contains(name))
	{
		return false;
	}

	return currentInputInfo_.at(name);
}

bool InputManager::IsTriggerd(const std::string& name) const
{
	if (!currentInputInfo_.contains(name))
	{
		return false;
	}

	return currentInputInfo_.at(name) && !lastInputInfo_.at(name);
}

void InputManager::Destroy(void)
{

	// �L�[���̃N���A
	keyInfos_.clear();
	mouseInfos_.clear();

	// �C���X�^���X�̃��������
	delete instance_;

}

void InputManager::Add(int key)
{
	InputManager::Info info = InputManager::Info();
	info.key = key;
	info.keyOld = false;
	info.keyNew = false;
	info.keyTrgDown = false;
	info.keyTrgUp = false;
	keyInfos_.emplace(key, info);
}

void InputManager::Clear(void)
{
	keyInfos_.clear();
}

bool InputManager::IsNew(int key) const
{
	return Find(key).keyNew;
}

bool InputManager::IsTrgDown(int key) const
{
	return Find(key).keyTrgDown;
}

bool InputManager::IsTrgUp(int key) const
{
	return Find(key).keyTrgUp;
}

Vector2 InputManager::GetMousePos(void) const
{
	return mousePos_;
}

int InputManager::GetMouse(void) const
{
	return mouseInput_;
}

bool InputManager::IsClickMouseLeft(void) const
{
	return mouseInput_ == MOUSE_INPUT_LEFT;
}

bool InputManager::IsClickMouseRight(void) const
{
	return mouseInput_ == MOUSE_INPUT_RIGHT;
}

bool InputManager::IsTrgMouseLeft(void) const
{
	return FindMouse(MOUSE_INPUT_LEFT).keyTrgDown;
}

bool InputManager::IsTrgMouseRight(void) const
{
	return FindMouse(MOUSE_INPUT_RIGHT).keyTrgDown;
}

InputManager::InputManager(void)
	:
	keyInfos_(),
	mouseInfos_(),
	infoEmpty_(),
	mouseInfoEmpty_(),
	mousePos_(),
	mouseInput_(-1),
	padInfos_(),
	joyDInState_(),
	joyXInState_()
{
}

const InputManager::Info& InputManager::Find(int key) const
{

	auto it = keyInfos_.find(key);
	if (it != keyInfos_.end())
	{
		return it->second;
	}

	return infoEmpty_;

}

const InputManager::MouseInfo& InputManager::FindMouse(int key) const
{
	auto it = mouseInfos_.find(key);
	if (it != mouseInfos_.end())
	{
		return it->second;
	}

	return mouseInfoEmpty_;
}

InputManager::JOYPAD_TYPE InputManager::GetJPadType(JOYPAD_NO no) const
{
	return static_cast<InputManager::JOYPAD_TYPE>(GetJoypadType(static_cast<int>(no)));
}

DINPUT_JOYSTATE InputManager::GetJPadDInputState(JOYPAD_NO no)
{
	// �R���g���[�����
	GetJoypadDirectInputState(static_cast<int>(no), &joyDInState_);
	return joyDInState_;
}

XINPUT_STATE InputManager::GetJPadXInputState(JOYPAD_NO no)
{
	// �R���g���[�����
	GetJoypadXInputState(static_cast<int>(no), &joyXInState_);
	return joyXInState_;
}

void InputManager::SetJPadInState(JOYPAD_NO jpNo)
{

	int no = static_cast<int>(jpNo);
	auto stateNew = GetJPadInputState(jpNo);
	auto& stateNow = padInfos_[no];

	int max = static_cast<int>(JOYPAD_BTN::MAX);
	for (int i = 0; i < max; i++)
	{

		stateNow.ButtonsOld[i] = stateNow.ButtonsNew[i];
		stateNow.ButtonsNew[i] = stateNew.ButtonsNew[i];

		stateNow.IsOld[i] = stateNow.IsNew[i];
		//stateNow.IsNew[i] = stateNow.ButtonsNew[i] == 128 || stateNow.ButtonsNew[i] == 255;
		stateNow.IsNew[i] = stateNow.ButtonsNew[i] > 0;

		stateNow.IsTrgDown[i] = stateNow.IsNew[i] && !stateNow.IsOld[i];
		stateNow.IsTrgUp[i] = !stateNow.IsNew[i] && stateNow.IsOld[i];

	}

	stateNow.AKeyLX = stateNew.AKeyLX;
	stateNow.AKeyLY = stateNew.AKeyLY;
	stateNow.AKeyRX = stateNew.AKeyRX;
	stateNow.AKeyRY = stateNew.AKeyRY;

}

int InputManager::GetMouseWheelRot(void) const
{
	return mouseWheelRot_;
}

InputManager::JOYPAD_IN_STATE InputManager::GetJPadInputState(JOYPAD_NO no)
{

	JOYPAD_IN_STATE ret = JOYPAD_IN_STATE();

	auto type = GetJPadType(no);
	
	switch (type)
	{
	case InputManager::JOYPAD_TYPE::OTHER:
		break;
	case InputManager::JOYPAD_TYPE::XBOX_360:
	{
	}
	case InputManager::JOYPAD_TYPE::XBOX_ONE:
	{

		auto d = GetJPadDInputState(no);
		auto x = GetJPadXInputState(no);

		int idx;

		//   Y
		// X   B
		//   A

		idx = static_cast<int>(JOYPAD_BTN::TOP);
		ret.ButtonsNew[idx] = d.Buttons[3];// Y

		idx = static_cast<int>(JOYPAD_BTN::LEFT);
		ret.ButtonsNew[idx] = d.Buttons[2];// X

		idx = static_cast<int>(JOYPAD_BTN::RIGHT);
		ret.ButtonsNew[idx] = d.Buttons[1];// B

		idx = static_cast<int>(JOYPAD_BTN::DOWN);
		ret.ButtonsNew[idx] = d.Buttons[0];// A

		idx = static_cast<int>(JOYPAD_BTN::R_TRIGGER);
		ret.ButtonsNew[idx] = x.RightTrigger;// R_TRIGGER

		idx = static_cast<int>(JOYPAD_BTN::L_TRIGGER);
		ret.ButtonsNew[idx] = x.LeftTrigger; // L_TRIGGER

		idx = static_cast<int>(JOYPAD_BTN::R_SHOULDER);
		ret.ButtonsNew[idx] = d.Buttons[5]; // R_SHOULDER

		idx = static_cast<int>(JOYPAD_BTN::L_SHOULDER);
		ret.ButtonsNew[idx] = d.Buttons[4]; // L_SHOULDER

		idx = static_cast<int>(JOYPAD_BTN::START);
		ret.ButtonsNew[idx] = d.Buttons[7]; // L_SHOULDER

		// ���X�e�B�b�N
		ret.AKeyLX = d.X;
		ret.AKeyLY = d.Y;
		
		// �E�X�e�B�b�N
		ret.AKeyRX = d.Rx;
		ret.AKeyRY = d.Ry;

	}
		break;
	case InputManager::JOYPAD_TYPE::DUAL_SHOCK_4:
	case InputManager::JOYPAD_TYPE::DUAL_SENSE:
	{
		
		auto d = GetJPadDInputState(no);
		int idx;

		//   ��
		// ��  �Z
		//   �~

		idx = static_cast<int>(JOYPAD_BTN::TOP);
		ret.ButtonsNew[idx] = d.Buttons[3];// ��

		idx = static_cast<int>(JOYPAD_BTN::LEFT);
		ret.ButtonsNew[idx] = d.Buttons[0];// ��

		idx = static_cast<int>(JOYPAD_BTN::RIGHT);
		ret.ButtonsNew[idx] = d.Buttons[2];// �Z

		idx = static_cast<int>(JOYPAD_BTN::DOWN);
		ret.ButtonsNew[idx] = d.Buttons[1];// �~

		idx = static_cast<int>(JOYPAD_BTN::R_TRIGGER);
		ret.ButtonsNew[idx] = d.Buttons[7];// R_TRIGGER

		idx = static_cast<int>(JOYPAD_BTN::L_TRIGGER);
		ret.ButtonsNew[idx] = d.Buttons[6]; // L_TRIGGER

		// ���X�e�B�b�N
		ret.AKeyLX = d.X;
		ret.AKeyLY = d.Y;
		
		// �E�X�e�B�b�N
		ret.AKeyRX = d.Z;
		ret.AKeyRY = d.Rz;

	}
		break;
	case InputManager::JOYPAD_TYPE::SWITCH_JOY_CON_L:
		break;
	case InputManager::JOYPAD_TYPE::SWITCH_JOY_CON_R:
		break;
	case InputManager::JOYPAD_TYPE::SWITCH_PRO_CTRL:
		break;
	case InputManager::JOYPAD_TYPE::MAX:
		break;
	}

	return ret;

}

bool InputManager::IsPadBtnNew(JOYPAD_NO no, JOYPAD_BTN btn) const
{
	return padInfos_[static_cast<int>(no)].IsNew[static_cast<int>(btn)];
}

bool InputManager::IsPadBtnTrgDown(JOYPAD_NO no, JOYPAD_BTN btn) const
{
	return padInfos_[static_cast<int>(no)].IsTrgDown[static_cast<int>(btn)];
}

bool InputManager::IsPadBtnTrgUp(JOYPAD_NO no, JOYPAD_BTN btn) const
{
	return padInfos_[static_cast<int>(no)].IsTrgUp[static_cast<int>(btn)];
}

VECTOR InputManager::GetDirectionXZAKey(int aKeyX, int aKeyY) const
{

	VECTOR ret = { 0.0f, 0.0f, 0.0f };

	// �X�e�B�b�N�̌X�̓��͒l�́A
	// -1000.0f �` 1000.0f �͈̔͂ŕԂ��Ă��邪�A
	// X:1000.0f�AY:1000.0f�ɂȂ邱�Ƃ͖���(1000��500���炢���ő�)
	
	// �X�e�B�b�N�̓��͒l�� -1.0 �` 1.0 �ɐ��K��
	float dirX = static_cast<float>(aKeyX) / AKEY_VAL_MAX;
	float dirZ = static_cast<float>(aKeyY) / AKEY_VAL_MAX;

	// �s�^�S���X�̒藝�Ńj���[�g������Ԃ���̒����x�N�g���ɂ���
	// ( �~�`�̃f�b�h�]�[���ɂȂ� )

	// �������ɂ��A�����悻�̍ő�l��1.0�ƂȂ�
	float len = sqrtf(dirX * dirX + dirZ * dirZ);
	if (len < THRESHOLD)
	{
		// (0.0f, 0.0f, 0.0f)
		return ret;
	}

	// �f�b�h�]�[�����E����ɍăX�P�[�����O(�σf�b�h�]�[��)
	// ( �������l 0.35 �̏ꍇ�́A 0.0 �` 0.65 / 0.65 �ɂȂ� )
	float scale = (len - THRESHOLD) / (1.0f - THRESHOLD);
	dirX = (dirX / len) * scale;
	dirZ = (dirZ / len) * scale;

	// Z�͑O�ɓ|���ƃ}�C�i�X�l���Ԃ��Ă���̂Ŕ��]
	ret = VNorm({ dirX, 0.0f, -dirZ });

	return ret;

}
