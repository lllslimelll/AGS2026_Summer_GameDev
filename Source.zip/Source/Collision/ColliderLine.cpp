#include "..//Utility/AsoUtility.h"
#include "../Common/Transform.h"
#include "../Game/Actor/ActorBase.h"
#include "ColliderModel.h"
#include "ColliderLine.h"

ColliderLine::ColliderLine(
	CollisionProfileType type,
	ActorBase* owner,
	const VECTOR& localPosStart,
	const VECTOR& localPosEnd)
	:
	ColliderBase(SHAPE::LINE, type, owner),
	localPosStart_(localPosStart),
	localPosEnd_(localPosEnd)
{
}

ColliderLine::~ColliderLine(void)
{
}

void ColliderLine::SetLocalPosStart(const VECTOR& pos)
{
	localPosStart_ = pos;
}

void ColliderLine::SetLocalPosEnd(const VECTOR& pos)
{
	localPosEnd_ = pos;
}

const VECTOR& ColliderLine::GetLocalPosStart(void) const
{
	return localPosStart_;
}

const VECTOR& ColliderLine::GetLocalPosEnd(void) const
{
	return localPosEnd_;
}

VECTOR ColliderLine::GetPosStart(void) const
{
	return GetRotPos(localPosStart_);
}

VECTOR ColliderLine::GetPosEnd(void) const
{
	return GetRotPos(localPosEnd_);
}

bool ColliderLine::PushBackUp(
	const ColliderModel* colliderModel, Transform& transform,
	VECTOR upDir, float pushDistance, bool isExclude, bool isTarget) const
{
	bool isJump = false;

	// �X�e�[�W���f��(�n��)�Ƃ̏Փ�
	auto hits = MV1CollCheck_LineDim(
		colliderModel->GetOwner()->GetTransform().modelId, -1, GetPosStart(), GetPosEnd());

	for (int i = 0; i < hits.HitNum; i++)
	{
		auto hit = hits.Dim[i];

		// ���O�t���[���͖�������
		if (isExclude && colliderModel->IsExcludeFrame(hit.FrameIndex)) continue;
		// �w��t���[���ȊO�͖�������
		if (isTarget && !colliderModel->IsTargetFrame(hit.FrameIndex)) continue;

		// �Փ˒n�_����A������Ɉړ�
		transform.pos =
			VAdd(hit.HitPosition, VScale(upDir, pushDistance));

		isJump = true;
	}

	// ���o�����n�ʃ|���S�����̌�n��
	MV1CollResultPolyDimTerminate(hits);

	return isJump;
}

void ColliderLine::DrawDebug(int color)
{
	VECTOR s = GetPosStart();
	VECTOR e = GetPosEnd();

	// ������`��
	DrawLine3D(s, e, color);

	// �n�_�E�I�_�����̂ŕ⏕�\��
	DrawSphere3D(s, RADIUS, DIV_NUM, color, color, true);
	DrawSphere3D(e, RADIUS, DIV_NUM, color, color, true);
}