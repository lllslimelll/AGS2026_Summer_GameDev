// GameScene.h
#pragma once
#include "SceneBase.h"
#include <vector>
#include <memory>
class ActorBase;
class Player;
class Camera;
class StageManager;
class ItemManager;
class EnemyManager;
class SkyDome;
class GameUI;

class GameScene : public SceneBase
{
public:

    GameScene(void);
    ~GameScene(void) override;

    void Load(void) override;
    void Init(void) override;
    void Update(void) override;
    void Draw(void) override;

    // Actor �𐶐����ĊǗ����X�g�ɒǉ�����
    template<typename T, typename... Args>
    T* SpawnActor(Args&&... args)
    {
        auto actor = std::make_unique<T>(std::forward<Args>(args)...);
        T* ptr = actor.get();
        actors_.push_back(std::move(actor));
        return ptr;
    }

    // Actor ���擾����
    template<typename T>
    T* GetActor(void) const
    {
        for (auto& actor : actors_)
        {
            if (auto* ptr = dynamic_cast<T*>(actor.get()))
            {
                return ptr;
            }
        }
        return nullptr;
    }

private:

    // �S Actor ���ꌳ�Ǘ�
    std::vector<std::unique_ptr<ActorBase>> actors_;

    // UI�iActor �ł͂Ȃ��̂ŕʊǗ��j
    std::vector<std::unique_ptr<GameUI>> gameUIs_;

    // ���͒��ڎQ�Ƃ��K�v�Ȃ��̂����|�C���^�Ŏ���
    Player* player_ = nullptr;
    Camera* camera_ = nullptr;
    std::unique_ptr<StageManager>  stageMng_;
    std::unique_ptr<ItemManager>   itemMng_;
    std::unique_ptr<EnemyManager>  enemyMng_;
    SkyDome* skyDome_ = nullptr;

    int CreateShadowMap(void);
};