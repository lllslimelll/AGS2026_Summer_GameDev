#pragma once
#include "ActorBase.h"

class StaticMeshComponent;

class SkyDome : public ActorBase
{

public:

	// ���
	enum class STATE
	{
		NONE,
		STAY,
		FOLLOW
	};

	SkyDome(const ActorBase* followTransform);

	~SkyDome() override;

	void Init(void)   override;
	// �X�V
	void Update(void) override;

	// �`��
	void Draw(void) override;

private:

	// �Ǐ]�Ώۂ�Transform
	const ActorBase* followTarget_;

	StaticMeshComponent* mesh_ = nullptr;

	// ���
	STATE state_;

	// ��ԑJ��
	void ChangeState(STATE state);
	// �X�V
	void UpdateStay(void);
	void UpdateFollow(void);
};