#pragma once
#include <DxLib.h>
#include "../../../../Core/Vector3.h"
#include "EnemyBase.h"

class Player;

class EnemyGiant : public EnemyBase
{
public:

    // ���
    enum class STATE
    {
        NONE,
        THINK,
        IDLE,
        PATROL,
        CHASE,
        ATTACK,
        RETURN,
        END,
    };

    // �A�j���[�V�������
    enum class ANIM_TYPE
    {
        IDLE = 0,
        WALK = 1,
        RUN = 2,
        ATTACK = 3,
    };

    // �R���X�g���N�^
    EnemyGiant(const EnemyBase::EnemyData& data, Player& player);

    // �f�X�g���N�^
    ~EnemyGiant(void) override;

    void Init(void) override;
    void Draw(void) override;

protected:

    void UpdateProcess(void)     override;
    void UpdateProcessPost(void) override;

private:
    // �R���C�_�[�萔
    static constexpr Vector3 COL_CAPSULE_TOP_LOCAL_POS = Vector3(0.0f, 160.0f, 0.0f);
    static constexpr Vector3 COL_CAPSULE_DOWN_LOCAL_POS = Vector3(0.0f, 50.0f, 0.0f);
    static constexpr float   COL_CAPSULE_RADIUS = 40.0f;

    // ���f���萔
    static constexpr float SCALE = 1.0f;
    static constexpr Vector3 DEFAULT_LOCAL_ROT = Vector3(0.0f, 0.0f, 0.0f);

    // ����p�����[�^
    static constexpr float VIEW_DIST = 1000.0f;
    static constexpr float VIEW_ANGLE = 60.0f;
    static constexpr float VIEW_HALF_FOV = VIEW_ANGLE * 0.5f * 3.14159265f / 180.0f;

    // �U���p�����[�^
    static constexpr float ATTACK_SPHERE_RADIUS = 20.0f;
    static constexpr float ATTACK_DAMAGE = 20.0f;

    // �ړ��EAI�����p�����[�^
    static constexpr float SPEED_PATROL = 1.0f;
    static constexpr float SPEED_CHASE = 3.0f;
    static constexpr float DIST_ATTACK = 100.0f;
    static constexpr float DIST_CHASE = 500.0f;

    // �U���t���[���C���f�b�N�X
    int attackHandFrame_ = -1;

    STATE state_ = STATE::NONE;
    float step_ = 0.0f;
    bool  attackHit_ = false;

    Vector3 spawnPos_;

    // ��ԑJ��
    void ChangeState(STATE state);
    void ChangeStateNone(void);
    void ChangeStateThink(void);
    void ChangeStateIdle(void);
    void ChangeStatePatrol(void);
    void ChangeStateChase(void);
    void ChangeStateAttack(void);
    void ChangeStateReturn(void);
    void ChangeStateEnd(void);

    // �X�V
    void UpdateNone(void);
    void UpdateThink(void);
    void UpdateIdle(void);
    void UpdatePatrol(void);
    void UpdateChase(void);
    void UpdateAttack(void);
    void UpdateReturn(void);
    void UpdateEnd(void);

    // �w���p�[
    void  SetMoveDirToTarget(const Vector3& target);
    bool  InSearchCone(void)  const;
    float DistToPlayer(void)  const;
    void  PushBackFromPlayer(void);
};