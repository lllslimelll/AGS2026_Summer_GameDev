#pragma once
#include "../ActorBase.h"

class StaticMeshComponent;

class Rocket : public ActorBase
{
public:

    static constexpr int QUOTA = 5000;
    ~Rocket(void) override;

    void Init(void)   override;
    void Update(void) override;
    void Draw(void)   override;

    // �[�i
    void AddDelivery(int value);

    // �݌v�[�i�z
    int GetTotalDelivered(void) const;

    // �m���}�N���A������
    bool IsQuotaCleared(void) const;

    // ���f��ID�擾
    int  GetModelId(void) const;

private:

    StaticMeshComponent* mesh_ = nullptr;
    int totalDelivered_ = 0;
};