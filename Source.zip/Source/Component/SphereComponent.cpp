// Component/SphereComponent.cpp
#include "SphereComponent.h"

SphereComponent::SphereComponent(
    ActorBase& owner,
    float radius)
    : PrimitiveComponent(owner)
    , radius_(radius)
{
}

SphereComponent::~SphereComponent(void)
{
}

// ---------------------------------------------------------------
// �p�����[�^�̎擾�E�ݒ�
// ---------------------------------------------------------------

float SphereComponent::GetRadius(void) const
{
    return radius_;
}

void SphereComponent::SetRadius(float radius)
{
    radius_ = radius;
}

// ---------------------------------------------------------------
// ���[���h���W�ł̌`��擾
// ---------------------------------------------------------------

// ���̒��S�̃��[���h���W
Vector3 SphereComponent::GetCenter(void) const
{
    return GetWorldPos();
}

// ---------------------------------------------------------------
// �f�o�b�O�`��
// ---------------------------------------------------------------

void SphereComponent::Draw(void)
{
#ifdef _DEBUG
    Vector3 center = GetCenter();
    DrawSphere3D(
        VGet(center.x, center.y, center.z),
        radius_, 16,
        0xff0000, 0xff0000,
        false);
#endif
}