#include <algorithm>
#include "StaticMeshComponent.h"

StaticMeshComponent::StaticMeshComponent(
    ActorBase& owner,
    int modelId)
    : PrimitiveComponent(owner)
    , modelId_(modelId)
{
}

StaticMeshComponent::~StaticMeshComponent(void)
{
}

// ---------------------------------------------------------------
// ���C�t�T�C�N��
// ---------------------------------------------------------------

void StaticMeshComponent::Init(void)
{
    // �e�N���X�� Init ���ĂԁiCollisionManager �ɓo�^�j
    PrimitiveComponent::Init();

    // ���f���̓����蔻������Z�b�g�A�b�v
    if (modelId_ != -1)
    {
        MV1SetupCollInfo(modelId_);
    }
}

// ---------------------------------------------------------------
// ���f��
// ---------------------------------------------------------------

int StaticMeshComponent::GetModelId(void) const
{
    return modelId_;
}

void StaticMeshComponent::SetModelId(int modelId)
{
    modelId_ = modelId;

    if (modelId_ != -1)
    {
        MV1SetupCollInfo(modelId_);
    }
}

// ---------------------------------------------------------------
// ���O�t���[��
// ---------------------------------------------------------------

void StaticMeshComponent::AddExcludeFrame(const std::string& name)
{
    RegisterFrameIds(name, excludeFrameIds_);
}

void StaticMeshComponent::ClearExcludeFrames(void)
{
    excludeFrameIds_.clear();
}

bool StaticMeshComponent::IsExcludeFrame(int frameIndex) const
{
    return std::find(
        excludeFrameIds_.begin(),
        excludeFrameIds_.end(),
        frameIndex) != excludeFrameIds_.end();
}

// ---------------------------------------------------------------
// �Ώۃt���[��
// ---------------------------------------------------------------

void StaticMeshComponent::AddIncludeFrame(const std::string& name)
{
    RegisterFrameIds(name, includeFrameIds_);
}

void StaticMeshComponent::ClearIncludeFrames(void)
{
    includeFrameIds_.clear();
}

bool StaticMeshComponent::IsIncludeFrame(int frameIndex) const
{
    return std::find(
        includeFrameIds_.begin(),
        includeFrameIds_.end(),
        frameIndex) != includeFrameIds_.end();
}

void StaticMeshComponent::Update(void)
{
    if (modelId_ == -1) return;

    // �R���W�����������[���h�s��ɍ��킹�čX�V
    Matrix4x4 worldMat = GetWorldMat();
    MATRIX dxMat;
    for (int i = 0; i < 4; i++)
        for (int j = 0; j < 4; j++)
            dxMat.m[i][j] = worldMat.m[i][j];

    MV1SetMatrix(modelId_, dxMat);
    MV1RefreshCollInfo(modelId_);
}

// ---------------------------------------------------------------
// �`��
// ---------------------------------------------------------------

void StaticMeshComponent::Draw(void)
{
    if (modelId_ == -1) return;

    MV1DrawModel(modelId_);
}

// ---------------------------------------------------------------
// �t���[��������C���f�b�N�X���擾���ēo�^����
// ---------------------------------------------------------------

void StaticMeshComponent::RegisterFrameIds(
    const std::string& name,
    std::vector<int>& frameIds)
{
    if (modelId_ == -1) return;

    int frameNum = MV1GetFrameNum(modelId_);
    for (int i = 0; i < frameNum; i++)
    {
        std::string frameName = MV1GetFrameName(modelId_, i);
        if (frameName.find(name) != std::string::npos)
        {
            frameIds.push_back(i);
        }
    }
}